bennettroot = function(t, Gmax, Epi, beta,I)
{

pmax = (Gmax)/(1+Gmax)
sigma2 = I*(Gmax/(1+Gmax)-Epi)*(Epi-1/2)
a = Gmax/(1+Gmax) - Epi

rat = (a*I*t)/sigma2

log(1/beta)*a^2/sigma2 - ((1+rat)*log(1+rat)-rat)

}
bennett = function(Gmax, Epi, beta, I)
{
	uniroot(bennettroot, interval = c(.01,20), extendInt = "yes", Gmax=Gmax, Epi = Epi, beta = beta, I = I)$root
}


hoeffding = function(Gmax, Epi, beta, I)
{
	I^(-1/2)*(.5*log(1/beta)*(Gmax/(1+Gmax) - 1/2)^2)^.5
}

clt = function(Gmax, Epi, beta, I)
{
	sigma2 = (Gmax/(1+Gmax)-Epi)*(Epi-1/2)
	I^(-1/2)*qnorm(1-beta)*sqrt(sigma2)
}

