# # Read in Stata data
# # This code should be run if loading from original
# # Stata .dta file
# library(readstata13)
# tmp <- read.dta13("wls_b_13_06.dta")
# tmp <- tmp[tmp$xxrsib == "full siblings",]
# tmp <- tmp[tmp$sexrsp == tmp$ssbsex,]
# tmp <- tmp[tmp$yrer74>-3 & tmp$xyrer76 > -3,]
# 
# keep.cov <- c("age75","edelrs","edeqyr","gwiiq_bm","yrer74",
#               "age77","xedelrs","xedeqyr","swiiq_t","xyrer76","sexrsp")
# 
# map.ed <- list("nonrespondent"        = -3,
#                "hs grad/less"         = 12,
#                "1 yr college"         = 13,
#                "2 yr college"         = 14,
#                "3/more yrs college"   = 15,
#                "baccalaureate degree" = 16,
#                "master degree"        = 17,
#                "two-year master"      = 18,
#                "dds, lld, llb, jd"    = 19,
#                "phd, md, oth doctort" = 20)
# 
# tmp$edeqyr <- sapply(tmp$edeqyr, function(x) map.ed[[x]])
# 
# tmp <- tmp[,keep.cov]
# # tmp <- tmp[tmp$edelrs != tmp$xedelrs,]
# tmp <- tmp[pmin(tmp$edeqyr,tmp$xedeqyr) <= 12 & pmax(tmp$edeqyr,tmp$xedeqyr) >= 14,]
# tmp <- tmp[tmp$swiiq_t > -3,]


# Read preprocessed wide-format siblings data
# tmp <- read.csv("pre-processed_wls_siblings.csv")
tmp <- read.csv("pre-processed_wls_siblings_v2.csv")
tmp <- tmp[,-c(2,7)]
tmp <- tmp[tmp$edeqyr > -3 & tmp$xedeqyr > -3,]
tmp <- tmp[tmp$xyrer76 > 0 & tmp$yrer74 > 0,]

n <- nrow(tmp)
tmp$pair_id <- as.factor(1:n)
 
tmp.sib <- tmp[,c(10:9,5:8)]
names(tmp)[c(10:9,1:4)] <- c("pair_id","sex","age","college","iq","income")
names(tmp.sib) <- c("pair_id","sex","age","college","iq","income")

# Change to long-format siblings data
pairs.df <- rbind(tmp[,c(10:9,1:4)],tmp.sib)

# Construct treatment indicator
pairs.df$college <- as.numeric(pairs.df$college > 12)

# scale income for numerical stability of p computation
pairs.df$income  <- pairs.df$income/10

pairs.df$income <- log(pairs.df$income)

# drop non-response levels for sex
pairs.df$sex <- droplevels(pairs.df$sex)

#simple t-test using the covariate adjustment method in Rosenbaum (2002)
dage = pairs.df$age[1:n] - pairs.df$age[(n+1):(2*n)]
diq = pairs.df$iq[1:n] - pairs.df$iq[(n+1):(2*n)]
gend = pairs.df$sex[1:n]=="male"
dwage = pairs.df$income[1:n] - pairs.df$income[(n+1):(2*n)]
V <- 2*(pairs.df$college[1:n]) - 1
eps = lm(dwage~ dage-1)$resid
tmc = eps*V
t.test(tmc)

# Under assumption that iq is the only (or at least the overwhelming) important
# unobserved confounder, compute \pi's
library(survival) 

fit.Z <- clogit(college ~ iq + strata(pair_id), data = pairs.df)
#fit.Z <- glm(college~iq,data=pairs.df,family = binomial)
fit.Y <- lm(income ~ pair_id + iq + age, data = pairs.df)
se <- summary(fit.Y)$sigma

# Compute \pi's using formula at top of second column on p. 806 of Hsu & Small (2016)
p <- (exp(fit.Z$coefficients[1]*(pairs.df$iq[1:n]-pairs.df$iq[(n+1):(2*n)]))*
           exp(fit.Y$coefficients[n+1]*(pairs.df$iq[1:n]-pairs.df$iq[(n+1):(2*n)])*
                 abs(pairs.df$income[1:n]-pairs.df$income[(n+1):(2*n)])/se^2) + 1) /
  ((exp(fit.Z$coefficients[1]*(pairs.df$iq[1:n]-pairs.df$iq[(n+1):(2*n)]))+1)*
     (exp(fit.Y$coefficients[n+1]*(pairs.df$iq[1:n]-pairs.df$iq[(n+1):(2*n)])*
            abs(pairs.df$income[1:n]-pairs.df$income[(n+1):(2*n)])/se^2)+1))

# Compute associated \pi^*'s
p <- apply(cbind(p,1-p),1,max)

## Checking out the \pi's

# Figure 3
fig3 <- hist(p, breaks = 20, xlab = expression("estimated "*pi[i]*"*"),col = "grey",
             main = "", plot = FALSE)

# Figure 2, Right panel
pairs.f.df <- pairs.df[pairs.df$sex=="female",]
n.f <- nrow(pairs.f.df)/2
fig2.R <- hist(pairs.f.df$iq[1:n.f] - pairs.f.df$iq[(n.f+1):(2*n.f)], breaks=20, plot = FALSE)

# Figure 2, Left panel
pairs.m.df <- pairs.df[pairs.df$sex=="male",]
n.m <- nrow(pairs.m.df)/2
fig2.L <- hist(pairs.m.df$iq[1:n.m] - pairs.m.df$iq[(n.m+1):(2*n.m)], breaks=20, plot = FALSE)

# Figure 2, Bottom panel
fig2.B <- tabulate(p/(1-p))

# Figure 1, Top panel
diq.m <- (pairs.m.df$college[1:n.m]-pairs.m.df$college[(n.m+1):(2*n.m)]) *
  (pairs.m.df$iq[1:n.m]-pairs.m.df$iq[(n.m+1):(2*n.m)])
fig1.T <- boxplot(diq.m, horizontal = T, ylim = c(-40,60), xaxt = "n", plot = FALSE)
# Figure 2, Bottom panel
diq.f <- (pairs.f.df$college[1:n.f]-pairs.f.df$college[(n.f+1):(2*n.f)]) *
  (pairs.f.df$iq[1:n.f]-pairs.f.df$iq[(n.f+1):(2*n.f)])
fig1.B <- boxplot(diq.f, horizontal = T, ylim = c(-40,60), plot = FALSE)

## Estimated sensitivity parameters for cross-study calibration
# \Gamma 
Gmax <- max(p)/(1-max(p))
Gmax
# \bar{\Gamma}
Gbar <- mean(p)/(1-mean(p))
Gbar

# Using standard methods to determine sensitivity parameter
library(sensitivitymv)

senmvroot = function(gamma, y)
{
  senmv(y, gamma)$pval-0.05
}

uniroot(senmvroot, c(1,4), y = tmc)$root


## Form a 95% CI at (Gmax, Gmax) and at (Gmax, Gbar)
# Use Rosenbaum (2002) covariance adjustment to conduct test, but
# use analogue of permutation t test instead of his Signed rank

# function to find upper and lower sensitivity bounds using
# extended sensitivity analysis
extend_root = function(tau, G.max = 1, G.bar = G.max, alp)
{
  awage = (dwage - tau*V)
  #awage = (dwage - tau*V*dose)
  eps = lm(awage~dage-1)$resid
  Yobs = rep(0, 2*n)
  Yobs[1:n] = eps
  Yobs[(n+1):(2*n)] = -eps
  Z = (pairs.df$college == 1)
  index = rep(c(1:n), 2)
  
  extended_sensitivity(G.max, G.bar, tau=0, Yobs, Z, index, 
                       alp = alp, test.stat = "ttest")-.5
  
}

# compute sensitivity intervals
tictoc::tic()
CIupper.rand   = uniroot(extend_root, interval = c(0,20), alp = 0.05)$root
CIupper.extend = uniroot(extend_root, interval = c(0,20), G.max = Gmax, G.bar = Gbar, alp = 0.05)$root
CIupper.sup    = uniroot(extend_root, interval = c(0,20), G.max = Gmax, G.bar = Gmax, alp = 0.05)$root

CIlower.rand   = uniroot(extend_root, interval = c(-20, 0), alp = 0.05)$root
CIlower.extend = uniroot(extend_root, interval = c(-20, 0), G.max = Gmax, G.bar = Gbar, alp = 0.05)$root
CIlower.sup    = uniroot(extend_root, interval = c(-20,0), G.max = Gmax, G.bar = Gmax, alp = 0.05)$root
tictoc::toc()

# first column, first row of Table 3
I.WLS.rand   <- c(CIlower.rand, CIupper.rand)
# first column, second row of Table 3
I.WLS.sup    <- c(CIlower.sup, CIupper.sup)
# first column, third row of Table 3
I.WLS.extend <- c(CIlower.extend, CIupper.extend)

# first column, fourth row of Table 3
rel.length.WLS <- 1 - diff(c(CIlower.extend, CIupper.extend))/diff(c(CIlower.sup, CIupper.sup))
