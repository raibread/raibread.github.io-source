set.seed(19)

alp  <- 0.05
Gmax <- c(1,1.1,1.25,1.5,2.0)
Gbar <- c(seq(1,1.5,0.05),seq(1.6,2.0,0.1))

tau.1    <- 0.5*sqrt(1)
tau.2    <- 0.25*sqrt(1)
npairs  <- 100
nsim    <- 5000

mod <- function(x,b) {
  if(x%%b == 0) b
  else x%%b
}

simulate_pairs <- function(npairs, tau = 0, Gmax = 1, Gbar = Gmax, biased = FALSE)
{
  if(Gmax != Gbar){
    p        <- 2*(Gmax-Gbar)/((Gmax-1)*(Gbar+1))
    G.pairs  <- sample(c(1,Gmax),npairs,TRUE,c(p,1-p))
  } else {
    G.pairs  <- rep(Gmax,npairs)
  }
  
  pi.pairs  <- G.pairs/(1+G.pairs)  
  
  Z.pairs  <- rbinom(npairs,1,pi.pairs)
  Z        <- c(Z.pairs,1-Z.pairs)
  
  #Y <- Z*tau + rnorm(2*npairs,0,sqrt(1))  
  
  # index.by.Z <- rep(NA,2*npairs)
  # index.by.Z[which(Z==0)] <- 1:npairs
  # index.by.Z[which(Z==1)] <- 1:npairs
  # 
  # index      <- (1-Z)*npairs + index.by.Z
  
  eps <- c(rnorm(npairs,0,1),rep(0,npairs))
  if(biased) 
  {
    eps.biased <- rep(NA,2*npairs)
    for(i in 1:npairs) {
      eps.biased[i] <- max(eps[i],eps[i+npairs])
      eps.biased[i+npairs] <- min(eps[i],eps[i+npairs])
    }
    eps <- eps.biased
  }

  Y <- Z*tau + eps
  
  index.by.Z <- rep(NA,2*npairs)
  
  Z.0 <- Z == 0
  Z.1.ind <- which(!Z.0)
  Z.0.ind <- which(Z.0)
  
  index.by.Z[Z.0.ind] <- sapply(Z.0.ind,function(x) mod(x,npairs))
  index.by.Z[Z.1.ind] <- sapply(Z.1.ind,function(x) mod(x,npairs))
  
  index      <- (1-Z)*npairs + index.by.Z
  
  data      <- data.frame(p = c(pi.pairs,1-pi.pairs),Z = Z,Y = Y)
  
  data[index,] <- data
  rownames(data) <- 1:(2*npairs)
  
  return(list(index = rep(1:npairs,2), npairs = npairs, Yobs = data$Y, 
              Dobs = data$Y[1:npairs]-data$Y[(npairs+1):(2*npairs)], Z = data$Z,
              pi = pi.pairs))
}

sensitivity_test <- function(npairs, tau = 0, Gmax = 1, Gbar = Gmax, 
                             biased = FALSE, alternative = FALSE,
                             alp = 0.05, bet = alp/10) {
  if(alternative)
    tau.0 <- 0
  else
    tau.0 <- tau
  x   <- simulate_pairs(npairs,tau,Gmax,Gbar,biased)
  rej <- extended_sensitivity(Gmax,Gbar,tau.0,x$Yobs,x$Z,x$index,alp,bet)
  return(rej)
}


rej.sim.biased <- matrix(nrow = length(Gbar),ncol = length(Gmax),
                         dimnames = list(as.character(Gbar),as.character(Gmax)))
rej.alt.sim.0.5 <- matrix(nrow = length(Gbar),ncol = length(Gmax),
                          dimnames = list(as.character(Gbar),as.character(Gmax)))
rej.sim.unbiased <- matrix(nrow = length(Gbar),ncol = length(Gmax),
                           dimnames = list(as.character(Gbar),as.character(Gmax)))
rej.alt.sim.0.25 <- matrix(nrow = length(Gbar),ncol = length(Gmax),
                           dimnames = list(as.character(Gbar),as.character(Gmax)))

for(Gm in Gmax) {
  for(Gb in Gbar[Gbar <= Gm]){
    rej.sim.biased[as.character(Gb),as.character(Gm)] <-
      mean(sapply(1:nsim,function(x) sensitivity_test(npairs,0,Gm,Gb,TRUE,FALSE)))
    rej.sim.unbiased[as.character(Gb),as.character(Gm)] <-
      mean(sapply(1:nsim,function(x) sensitivity_test(npairs,0,Gm,Gb,FALSE,FALSE)))
    rej.alt.sim.0.5[as.character(Gb),as.character(Gm)] <-
      mean(sapply(1:nsim,function(x) sensitivity_test(npairs,tau.1,Gm,Gb,FALSE,TRUE)))
    rej.alt.sim.0.25[as.character(Gb),as.character(Gm)] <-
      mean(sapply(1:nsim,function(x) sensitivity_test(npairs,tau.2,Gm,Gb,FALSE,TRUE)))
  }
}

