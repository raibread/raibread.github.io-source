
# function to maximize the RHS of (17) subject to (18)
G_beta <- function(G.bar,G.max,npairs,bet) {
  k.beta <- qnorm(1-bet)
  pi.tmp <- function(E.pi,k.beta,G.max,npairs) {
    return(E.pi + k.beta*sqrt((G.max/(1+G.max)-E.pi)*(E.pi-0.5)/npairs))
  }
  if(G.bar > 1) {
    pi.beta <- optimize(function(e.pi) pi.tmp(e.pi,k.beta,G.max,npairs),
                        c(1/2,G.bar/(1+G.bar)), maximum = TRUE)$objective
  } else {
    pi.beta <- 1/2
  }
  
  return(pi.beta/(1-pi.beta))
}

# function to compute scores for sign-rank test statistic
q_signrank <- function(Yobs,Z,index,tau=0) {
  # compute potential outcomes under control and H_\tau
  Yobs <- Yobs - tau*Z
  
  # number of pairs
  npairs <- length(Z)/2
  q = rep(0, npairs)
  
  # compute ranks
  r <- rank(sapply(1:npairs,
                   function(j){
                     ind <- which(index==j)
                     r   <- abs(Yobs[ind[1]] - Yobs[ind[2]])
                   }))
  
  # compute signed ranks
  for(j in 1:npairs)
  {
    ind <- which(index==j)
    q[ind[1]] <- sign((Yobs[ind[1]] - Yobs[ind[2]]))*r[j]
    q[ind[2]] <- -q[ind[1]]
  }
  return(q)  
}

# function to compute scores for permutational t-test
q_ttest <- function(Yobs,Z,index,tau=0) {
  # compute potential outcomes under control and H_\tau
  Yobs <- Yobs - tau*Z
  
  # number of pairs
  npairs <- length(Z)/2
  q = rep(0, npairs)
  
  for(j in 1:npairs)
  {
    ind <- which(index==j)
    q[ind[1]] <- Yobs[ind[1]] - Yobs[ind[2]]
    q[ind[2]] <- -q[ind[1]]
  }
  return(q) 
}

# function to compute scores for m-estimates
q_mstat <- function(Yobs,Z,index,tau=0,psi = c("huber","custom"),C=1,h = median,psi.fn = NULL) {
  
  psi.type <- match.arg(psi)
  
  if(is.null(psi.fn) && psi == "custom")
    stop("must specifiy psi.fn if using a custom odd-function for m-estimate")
  
  psi <- switch(psi.type,
          huber  = function(x) pmax(pmin(x,C),-C),
          custom = psi.fn)
  
  # compute m-estimate terms under H_\tau
  D.tau   <- q_ttest(Yobs,Z,index,tau)
  h.tau   <- h(abs(D.tau))
  psi.tau <- psi(abs(D.tau)/h.tau)
  
  # number of pairs
  npairs <- length(Z)/2
  q = rep(0, npairs)
  
  for(j in 1:npairs)
  {
    ind <- which(index==j)
    q[ind[1]] <- sign(D.tau[ind[1]])*psi.tau[ind[1]]
    q[ind[2]] <- -q[ind[1]]
  }
  return(q) 
}

extended_sensitivity <- function(G.max = 1, G.bar = G.max, tau = 0, 
                                 Yobs, Z, index, alp = 0.05, bet = alp/10,
                                 test.stat = c("ttest","mstat","signrank","custom"),
                                 custom.fn = NULL, superpopulation = T,...)
{
  test.stat <- match.arg(test.stat)
  
  require(gurobi)
  require(Matrix)
  
  npairs <- length(Z)/2
  q      <- rep(0, npairs)
  
  if(G.bar == G.max || superpopulation == F)
  {
    G.beta <- G.bar
    alpha  <- alp 
  } else {
    G.beta <- G_beta(G.bar,G.max,npairs,bet)
    alpha  <- alp - bet
  }

  q <- switch(test.stat,
              ttest    = q_ttest(Yobs,Z,index,tau),
              mstat    = q_mstat(Yobs,Z,index,tau,...),
              signrank = q_signrank(Yobs,Z,index,tau),
              custom   = Yobs)
  
  if(!is.null(custom.fn) && test.stat == "custom") 
    q <- custom.fn(Yobs,Z,index,tau,...)
  if(is.null(custom.fn) && tau != 0 && test.stat == "custom")
    warning("If you input custom scores directly, 
            you must adjust for tau prior to calling extended_sensitivity()")
  Q.temp <- q
  #observed test statistic    
  Tobs = sum(Z*Q.temp)
  
  if(Tobs > 1/2*sum(q))
  {
 
  

  #rearrange pairs such that max Q association with first index
  #
  Q = rep(0, 2*npairs)
  for(j in 1:npairs)
  {
    ind = which(index==j)
    Q[ind[1]] = max(Q.temp[ind[1]], Q.temp[ind[2]])
    Q[ind[2]] = min(Q.temp[ind[1]], Q.temp[ind[2]])
  }
  
  #3npair +1 variables. 
  #first npair columns for p_i, second npair columns for stratum-wise expectation of square, third npair columns for stratum-wise  expectation, last single column for observed test statistic minus the overall expectation
  #easier to write the objective function this way
  
  #2npair + 2 constraints
  #2npair for defining pairwise expectation and expectation of square
  #1 for the constraint imposed by our new Gamma
  #1 for defining a variable (Tobs - overall expectation)
  
  #program looks like:
  #min_p (Tobs - E[Z^Tq])^2 - \chi^2_{1, 1-\alpha}*Var(Z^Tq)
  #s.t mean(p_i) = Gamma/(1+Gamma)
  #when we no longer can reject the null, optimal objective value will be zero
  
  #as written, program works if Tobs >= E[Z^Tq]. 
  #If Tobs <= E[Z^Tq], just redefine q' = -q
  
  #build the constraint matrix as a sparse matrix
  ntot = 6*npairs+1
  nr = 2*npairs+2
  rowind = rep(0, ntot)
  
  colind = rep(0, ntot)
  values = rep(0, ntot)
  b = rep(0, nr)
  
  rowind[1:(4*npairs)] = rep((1):(2*npairs), each = 2)
  colind[1:(2*npairs)] = rep(1:npairs, each = 2) + rep(c(0, npairs), npairs)
  colind[(2*npairs+1):(4*npairs)] = rep(1:npairs, each = 2) + rep(c(0, 2*npairs), npairs)
  
  
  aa = (0:(npairs-1))*2
  for(i in 1:npairs)
  {
    ind = which(index==i)
    values[c(aa[i]+c(1,2))] = c(Q[ind[1]] - Q[ind[2]], -1) 
    values[c(2*npairs+aa[i]+c(1,2))] = c(Q[ind[1]]^2 - Q[ind[2]]^2, -1)
    b[((0:1)*npairs + i)] =   c(-Q[ind[2]], -Q[ind[2]]^2)
  }
  b[(2*npairs+2)] = Tobs
  rowind[(4*npairs+1):(5*npairs)] = rep(2*npairs+1, npairs)
  colind[(4*npairs+1):(5*npairs)] = (1):(npairs)
  values[(4*npairs+1):(5*npairs)] = rep(1, npairs)
  rowind[(5*npairs+1):(6*npairs+1)] = rep(2*npairs+2, npairs+1)
  colind[(5*npairs+1):(6*npairs+1)] = c((npairs+1):(2*npairs), 3*npairs+1)
  values[(5*npairs+1):(6*npairs+1)] = c(rep(1, npairs+1))
  rowindq = c((npairs+1):(2*npairs), 3*npairs+1)
  colindq = c((npairs+1):(2*npairs), 3*npairs+1)
  valuesq = c(rep(qchisq(1-alpha, 1), npairs), 1)
  objlin = c(rep(0, 2*npairs), rep(-qchisq(1-alpha, 1), npairs), 0)
  const.dir = c(rep("=", 2*npairs),"<=", "=")
  model = list()
  model$A = sparseMatrix(rowind, colind, x= values)
  model$sense = const.dir
  model$lb = c(rep(0.5, npairs), rep(-Inf, 2*npairs+1))
  model$ub = c(rep(G.max/(1+G.max), npairs), rep(Inf, 2*npairs+1))
  model$obj = objlin
  model$Q = sparseMatrix(rowindq, colindq, x= valuesq)
  model$vtypes = c(rep("C", 3*npairs+1))
  model$modelsense = "min"
  
  G = G.beta
  b[(2*npairs+1)] = npairs*G/(1+G)
  model$rhs = b
  sol = gurobi(model, params = list(OutputFlag = 0))
  rej.1 = sol$objval > 0
  
  
  #if(sol$x[3*npairs+1] > 0) rej = rej.1
   rej = rej.1
  }else{
    Q.temp = -q  
    
    #observed test statistic    
    Tobs = sum(Z*Q.temp)
    
    Q = rep(0, 2*npairs)
    for(j in 1:npairs)
    {
      ind = which(index==j)
      Q[ind[1]] = max(Q.temp[ind[1]], Q.temp[ind[2]])
      Q[ind[2]] = min(Q.temp[ind[1]], Q.temp[ind[2]])
    }
    
    #3npair +1 variables. 
    #first npair columns for p_i, second npair columns for stratum-wise expectation of square, third npair columns for stratum-wise  expectation, last single column for observed test statistic minus the overall expectation
    #easier to write the objective function this way
    
    #2npair + 2 constraints
    #2npair for defining pairwise expectation and expectation of square
    #1 for the constraint imposed by our new Gamma
    #1 for defining a variable (Tobs - overall expectation)
    
    #program looks like:
    #min_p (Tobs - E[Z^Tq])^2 - \chi^2_{1, 1-\alpha}*Var(Z^Tq)
    #s.t mean(p_i) = Gamma/(1+Gamma)
    #when we no longer can reject the null, optimal objective value will be zero
    
    #as written, program works if Tobs >= E[Z^Tq]. 
    #If Tobs <= E[Z^Tq], just redefine q' = -q
    
    #build the constraint matrix as a sparse matrix
    ntot = 6*npairs+1
    nr = 2*npairs+2
    rowind = rep(0, ntot)
    
    colind = rep(0, ntot)
    values = rep(0, ntot)
    b = rep(0, nr)
    
    rowind[1:(4*npairs)] = rep((1):(2*npairs), each = 2)
    colind[1:(2*npairs)] = rep(1:npairs, each = 2) + rep(c(0, npairs), npairs)
    colind[(2*npairs+1):(4*npairs)] = rep(1:npairs, each = 2) + rep(c(0, 2*npairs), npairs)
    
    
    aa = (0:(npairs-1))*2
    for(i in 1:npairs)
    {
      ind = which(index==i)
      values[c(aa[i]+c(1,2))] = c(Q[ind[1]] - Q[ind[2]], -1) 
      values[c(2*npairs+aa[i]+c(1,2))] = c(Q[ind[1]]^2 - Q[ind[2]]^2, -1)
      b[((0:1)*npairs + i)] =   c(-Q[ind[2]], -Q[ind[2]]^2)
    }
    b[(2*npairs+2)] = Tobs
    rowind[(4*npairs+1):(5*npairs)] = rep(2*npairs+1, npairs)
    colind[(4*npairs+1):(5*npairs)] = (1):(npairs)
    values[(4*npairs+1):(5*npairs)] = rep(1, npairs)
    rowind[(5*npairs+1):(6*npairs+1)] = rep(2*npairs+2, npairs+1)
    colind[(5*npairs+1):(6*npairs+1)] = c((npairs+1):(2*npairs), 3*npairs+1)
    values[(5*npairs+1):(6*npairs+1)] = c(rep(1, npairs+1))
    rowindq = c((npairs+1):(2*npairs), 3*npairs+1)
    colindq = c((npairs+1):(2*npairs), 3*npairs+1)
    valuesq = c(rep(qchisq(1-alpha, 1), npairs), 1)
    objlin = c(rep(0, 2*npairs), rep(-qchisq(1-alpha, 1), npairs), 0)
    const.dir = c(rep("=", 2*npairs),"<=", "=")
    model = list()
    model$A = sparseMatrix(rowind, colind, x= values)
    model$sense = const.dir
    model$lb = c(rep(0.5, npairs), rep(-Inf, 2*npairs+1))
    model$ub = c(rep(G.max/(1+G.max), npairs), rep(Inf, 2*npairs+1))
    model$obj = objlin
    model$Q = sparseMatrix(rowindq, colindq, x= valuesq)
    model$vtypes = c(rep("C", 3*npairs+1))
    model$modelsense = "min"
    
    G = G.beta
    b[(2*npairs+1)] = npairs*G/(1+G)
    model$rhs = b
    sol = gurobi(model, params = list(OutputFlag = 0))
    rej.2 = sol$objval > 0
    rej = rej.2
  }
  return(rej)
}