# Read in Ashenfelter twins data
twins = read.csv("pubtwins.csv")

edu1 = twins$educ
edu2 = twins$educ_t
lwage1 = twins$lwage
lwage2 = twins$lwage_t

# Find twin pairs discordant in treatment
# hsvcoll = (pmin(edu1, edu2) <= 12 & pmax(edu1, edu2) >= 14)
hsvcoll = (edu1 <= 12 & edu2 >= 14)

edu1.sub = edu1[hsvcoll]
edu2.sub = edu2[hsvcoll]
lwage1.sub = lwage1[hsvcoll]
lwage2.sub = lwage2[hsvcoll]

#simple t-test (no adjustment for age since they are twins)
V = 2*(edu1.sub > edu2.sub)-1
tmc = (lwage1.sub-lwage2.sub)*V
t.test(tmc)

# Using standard methods to determine sensitivity parameter
library(sensitivitymv)

senmvroot = function(gamma, y)
{
  senmv(y, gamma)$pval-0.05
}
uniroot(senmvroot, c(1,4), y = tmc)$root

## Form a 95% CI at (Gmax, Gmax) and at (Gmax, Gbar)
# Use Rosenbaum (2002) covariance adjustment to conduct test, but
# use analogue of permutation t test instead of his Signed rank

# function to find upper and lower sensitivity bounds using
# extended sensitivity analysis
extend_root_twins = function(tau, G.max = 1, G.bar = G.max, alp, bet = alp/10)
{

  ntwin = length(lwage1.sub)
  Ytwin =rep(0, 2*ntwin)
  
  awage = (lwage1.sub-lwage2.sub) - tau*V

  eps = awage
  
  Ytwin[1:ntwin] = eps
  Ytwin[(ntwin+1):(2*ntwin)] = -eps
  Ztwin = c((edu1.sub > edu2.sub), 1 - (edu1.sub > edu2.sub))
  indextwin = rep(1:ntwin, 2)
  
  extended_sensitivity(G.max, G.bar, tau=0, Ytwin, Ztwin, indextwin, 
                       alp = alp, bet = bet, test.stat = "ttest")-.5
  
}

# compute sensitivity intervals

#These are 95% CIS
tictoc::tic()
CIupper.rand   = uniroot(extend_root_twins, interval = c(0.2,1), alp = 0.05)$root
CIupper.extend = uniroot(extend_root_twins, interval = c(0.2,1), G.max = Gmax, G.bar = Gbar, alp = 0.05, bet = 0.005)$root
CIupper.sup    = uniroot(extend_root_twins, interval = c(1, 1.8), G.max = Gmax, G.bar = Gmax, alp = 0.05, bet = 0.005)$root
CIlower.rand   = uniroot(extend_root_twins, interval = c(-20, CIupper.rand-.1), alp = 0.05)$root
CIlower.extend = uniroot(extend_root_twins, interval = c(-20, CIupper.extend-.1), G.max = Gmax, G.bar = Gbar, alp = 0.05, bet = 0.005)$root
CIlower.sup    = uniroot(extend_root_twins, interval = c(-20,-.5), G.max = Gmax, G.bar = Gmax, alp = .05, bet = 0.005)$root
tictoc::toc()


# second column, first row of Table 3
I.Ash.rand <- c(CIlower.rand, CIupper.rand)
# second column, second row of Table 3
I.Ash.sup <- c(CIlower.sup, CIupper.sup)
# second column, third row of Table 3
I.Ash.extend <- c(CIlower.extend, CIupper.extend)


exp(I.Ash.rand)
exp(I.Ash.sup)
exp(I.Ash.extend)
# second column, fourth row of Table 3
rel.length.Ash <- 1 - diff(c(CIlower.extend, CIupper.extend))/diff(c(CIlower.sup, CIupper.sup))

# Figure 4, Calibration plot
G.grid <- seq(1,10,0.01)

ext.curve <- function(g) {
  x <- tryCatch(uniroot(function(gb) extend_root_twins(0,g,gb,0.05),
                        interval = c(1,g))$root, error = function(e) g)
}

Gb <- sapply(G.grid,ext.curve)
