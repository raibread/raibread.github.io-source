rm(list = ls())
## extended sensitivity functions
source("extended_sensitivity.R")

## WLS siblings analysis
source("WLS_siblings.R")

# Figure 1, Top panel
bxp(fig1.T, horizontal = TRUE, xaxt = 'n', ylim = c(-40,60), yaxt = 'n')
abline(v = 0, col = 'grey', lty = 3)
par(las = 0)
mtext(side = 2, text = 'Male Siblings', line = .5)
# Figure 2, Bottom panel
bxp(fig1.B, horizontal = TRUE, ylim = c(-40,60), 
    yaxt = 'n', xlab = expression(Delta*IQ))
par(las = 0)
mtext(side = 2, text = 'Female Siblings', line = .5)
abline(v = 0, col = 'grey', lty = 3)

# Figure 2, Left panel
plot(fig2.L,xlab = expression(Delta*IQ),col = "grey",
     main = "Male Siblings")
# Figure 2, Right panel
plot(fig2.R, xlab = expression(Delta*IQ),col = "grey",
     main = "Female Siblings")
# Figure 2, Bottom panel
fig2.B <- fig2.B[c(1,2,3,6,7,9)]
names(fig2.B) <- c("[1,2)","[2,3)","[3,6)","[6,7)","[7,9)","[9,10)")
xtable(as.data.frame(t(fig2.B)))

# Figure 3
plot(fig3, xlab = expression("estimated "*pi[i]*"*"),col = "grey",
     main = "")

# first column, first row of Table 3
I.WLS.rand
# first column, second row of Table 3
I.WLS.sup
# first column, third row of Table 3
I.WLS.extend
# first column, fourth row of Table 3
rel.length.WLS

## Ashenfelter twins analysis
source("Ashenfelter_twins.R")
# second column, first row of Table 3
I.Ash.rand
# second column, second row of Table 3
I.Ash.sup
# second column, third row of Table 3
I.Ash.extend
# second column, fourth row of Table 3
rel.length.Ash

# Figure 4, Calibration plot
par(mar=c(5.1,5.1,4.1,2.1))
plot(NA,NA,type = 'l',lty = 3,xlim = c(1,10),ylim = c(1,3), col = 'grey',
     xaxs = "i", yaxs = "i", xaxt = 'n', yaxt = 'n',
     ylab = expression(bar(Gamma)), xlab = expression(Gamma), cex.lab = 2)
polygon(c(G.grid,rev(G.grid)),c(Gb,rep(0,length(Gb))),col = 'grey', border = 'grey')
lines(c(10,10),c(1,1.25))
axis(side = 2, at = c(1,1.1,1.25,1.5,2,3),c(1,1.1,1.25,1.5,2,3),cex.axis = 1.2)
axis(side = 1, at = c(1,2,3,5,9.3,10),c(1,2,3,5,9.3,10),cex.axis = 1.2)
abline(a=0,b=1,col = 'black', lty = 2)
points(9.3,1.1,pch = 3,col = 'blue')
text(8.25,1.1,"WLS IQ Calibration",col = 'blue',cex = 1.5)
text(6.5,2,expression(paste("retain ", H[0])),col = 'black',cex = 2)
text(2.25,1.2,expression(paste("reject ", H[0])),col = 'black',cex = 2)


## Level and power simulations (may be slightly different than paper due to Monte Carlo approx. error)
source("level_and_power_simulations.R")

# Table 1, main text
rej.sim.biased 
# Table 2, main text
rej.alt.sim.0.5
# Table 1, supplement
rej.sim.unbiased
# Table 2, supplement
rej.alt.sim.0.25
