%% ------------------------------------------------------------------------
% Set parameters
% -------------------------------------------------------------------------
if ~exist('spec_file','var')
    spec_file = 'spec01';
end
eval(spec_file);
test = testVars(testName,{},semicond);

%% ------------------------------------------------------------------------
% load predictive densities
% -------------------------------------------------------------------------

% if semi-conditional, change save file names
if semicond             
  p_string='_semicond'; 
else
  p_string='';
end

f904 = fopen(['densities/predictive_density_means_904_10-Jan-1992_to_10-Apr-2011_',testName,p_string],'r');
f805 = fopen(['densities/predictive_density_means_805_10-Jan-1992_to_10-Apr-2011_',testName,p_string],'r');
p904 = fread(f904,'single');
p805 = fread(f805,'single');

% get date series
fd904 = fopen(['densities/predictive_density_fdates_904_10-Jan-1992_to_10-Apr-2011_',testName,p_string],'r');
dt    = fread(fd904,'single');

if exist('T','var')
    dt = dt(1:T,1);
    p904 = p904(1:T,1);
    p805 = p805(1:T,1);
end
    

%% ------------------------------------------------------------------------
% Reorganize parameters of input functions
% -------------------------------------------------------------------------
[prior_fcn,prior_fcn_sep] = gen_prior(prior_spec);
[prop_fcn,propPr_fcn] = gen_prop(prop_spec);

%% ------------------------------------------------------------------------
% Argument lists for functions being passed to pmmh(...)
% -------------------------------------------------------------------------
filter_args = {p904,p805,G_in,K_in,fK_in,para_names};
prior_args  = {};
prop_args   = {};
propPr_args = prop_args;

if ~isempty(fixed_spec)
    filter_args{end+1} = fixed_spec;
end

%% ------------------------------------------------------------------------
% Run PMMH algorithm
% -------------------------------------------------------------------------
tic;

[draws_para,draws_lam,rej_prct,draws_LL,draws_pri] = pmmh2(prior_fcn,...
    @fnPoolFilter2,prop_fcn,propPr_fcn,para_init,N,prior_args,filter_args,...
    prop_args,propPr_args);

toc;

if exist('T','var')
    draws_lam = draws_lam(:,T);
end

%% ------------------------------------------------------------------------
% Save Results
% -------------------------------------------------------------------------
if save_results
    %% --------------------------------------------------------------------
    % Set file name suffix
    % ---------------------------------------------------------------------
    save_suffix = [testName,'_N',num2str(N),'_G',num2str(G_in),'_K',...
        num2str(K_in),'_ESS',num2str(100*fK_in),'_',spec_file,p_string];
    
    %% --------------------------------------------------------------------
    % Set directory
    % ---------------------------------------------------------------------
    
    % spec specific directory
    resultsDir = ['results/',spec_file,'/'];
    
    % semiconditional subdirectory
    if semicond
        resultsDir = [resultsDir,'semicond/'];
    else
        resultsDir = [resultsDir,'uncond/'];
    end
    
    % dated directory
    resultsDir = [resultsDir,datestr(now,'YYYYmmdd-HHMMSS'),'/'];
    if ~exist(resultsDir,'dir')
        mkdir(resultsDir);
    end
    
    %% --------------------------------------------------------------------
    % save draws
    % ---------------------------------------------------------------------
    for i_ = 1:k
        f = fopen([resultsDir,'draws_',para_names{i_},'_',save_suffix],'w');
        
        fwrite(f,draws_para(:,i_),'single');
        fclose(f);
    end
    
    % lambda_t
    f = fopen([resultsDir,'draws_lam_',save_suffix],'w');
    fwrite(f,draws_lam,'single');
    fclose(f);
    
    % log likelihood
    f = fopen([resultsDir,'draws_LL_',save_suffix],'w');
    fwrite(f,draws_LL,'single');
    fclose(f);
    
    % log prior
    f = fopen([resultsDir,'draws_pri_',save_suffix],'w');
    fwrite(f,draws_pri,'single');
    fclose(f);
    
    % rejection percentage
    f = fopen([resultsDir,'rej_prct_',save_suffix],'w');
    fwrite(f,rej_prct,'single');
    fclose(f);
    
    %% --------------------------------------------------------------------
    % Burn baby burnnnnn
    % ---------------------------------------------------------------------
    draws_para = draws_para(nb+1:end,:);
    draws_lam  = draws_lam(nb+1:end,:);
    draws_LL   = draws_LL(nb+1:end,1);
    draws_pri  = draws_pri(nb+1:end,1);

    %% --------------------------------------------------------------------
    % Map mu to lambda space 
    % ---------------------------------------------------------------------
    i_mu = find(cell2mat(cellfun(@(x) strcmp('mu',x{1}),...
        prior_spec,'UniformOutput',0)));
    if ~isempty(i_mu)
        draws_para(:,i_mu,:) = normcdf(draws_para(:,i_mu,:));
        support_spec{i_mu}{2} = normcdf(support_spec{i_mu}{2});
        
        % deals with numerical issues at boundaries
        adj = 1e-10;
        support_spec{i_mu}{2}(1) = support_spec{i_mu}{2}(1) + adj;
        support_spec{i_mu}{2}(2) = support_spec{i_mu}{2}(2) - adj;
        
        % change of variable (lambda = cdf(mu))
        tmp_fcn = prior_fcn_sep{i_mu}
        tmp_fcn = @(x) tmp_fcn(norminv(x)).*exp(norminv(x).^2/2)*sqrt(2*pi);
        prior_fcn_sep{i_mu} = tmp_fcn;
        
    end
    
    %% --------------------------------------------------------------------
    % save marginal density plots
    % ---------------------------------------------------------------------
    for j_ = 1:k
        fig = figure();
        
        % adjust histogram bounds for parameters with inf. support
        tmp_support = support_spec{j_}{2};
        if tmp_support(1) == -Inf
            tmp_support(1) = min(min(draws_para(:,j_,:)));
        end
        if tmp_support(2) == Inf
            tmp_support(2) = max(max(draws_para(:,j_,:)));
        end
        
        % generate histogram with freedman-diaconis bin width rule
        bar2(draws_para(:,j_),'fre-dia',tmp_support);
        hold on;
        
        % plot prior
        prior_fcn_tmp = prior_fcn_sep{j_};
        gridpts = tmp_support(1):diff(tmp_support)/1000:tmp_support(2);
        plot(gridpts,prior_fcn_tmp(gridpts),'r','LineWidth',2);
        
        % save
        hgsave(fig,[resultsDir,'HISTOGRAM_draws_',...
            para_names{j_},'_',save_suffix,'.fig']);
    end
    
    %% --------------------------------------------------------------------
    % Plot 2d distributions, weight evolution, log score, etc.
    % ---------------------------------------------------------------------
    lRep = draws_lam;
    wRep = ones(size(lRep))*1/(N-nb);
    
    plotResults;
    plotResults2;
    
    %% --------------------------------------------------------------------
    % histogram evolution (filtered lambda)
    % ---------------------------------------------------------------------
    fig = figure();
    
    % generate histogram evolution with freedman-diaconis bin width rule
    hist_out = hist_evol(draws_lam,dt + test.k*0.25,[0,1],'fre-dia',1);
    
    % save
    hgsave(fig,[resultsDir,'HISTOGRAM_evol_',save_suffix,'.fig']);
    
    %% --------------------------------------------------------------------
    % Make these .fig files .png files!!!
    % ---------------------------------------------------------------------
    [rc list_fig] = system(['ls ',resultsDir,' | grep .fig']);
        list_fig = regexp(list_fig,'\n','split');
        for j_ = 1:length(list_fig)
            tmp_file = [resultsDir,list_fig{j_}];
            if exist(tmp_file,'file') && ~strcmp(list_fig{j_},'')
                h = hgload(tmp_file);
                print(h,'-r300','-dpng',strrep(tmp_file,'.fig','.png'));
                system(['rm ',tmp_file]);
            end
        end
    
    %% --------------------------------------------------------------------
    % save spec file
    % ---------------------------------------------------------------------
    ok1 = parse_spec(resultsDir,'figures');
    ok2 = figure_tex(resultsDir,'figures','fig');
end




