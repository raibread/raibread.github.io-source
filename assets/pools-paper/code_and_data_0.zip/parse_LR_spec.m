function [ok] = parse_LR_spec(resultsDir,dropbox_adj)
ok = 0;

spec_file = regexp(resultsDir,'(?<=/)(LR_)?spec[0-9]*(?=/)','match');
spec_file = spec_file{1};
eval([spec_file,';']);

f = fopen([resultsDir,spec_file,'.txt'],'w');

fprintf(f,'########## Model Spec: %s ##########\n\n',spec_file);

fcast_type = '';
if strcmp(testName,'output_and_inflation_annualized')
    fcast_type = [fcast_type,'4Q gdp and inf.'];
elseif strcmp(testName,'output_and_inflation')
    fcast_type = [fcast_type,'1Q gdp and inf.'];
else
    error(['predictive density ',testName,' not supported']);
end

if semicond
    fcast_type = [fcast_type,' (semiconditional)'];
end

fprintf(f,'Predictive density: %s\n',fcast_type);
fprintf(f,'########## Directories ##########\n');
fprintf(f,'Results directory: %s\n',resultsDir);

tmp = regexp(resultsDir,'^\w+(?=/.*)','match');
dropboxDir = strrep(resultsDir,tmp{1},dropbox_adj);
fprintf(f,'Dropbox directory: %s\n',dropboxDir);

fprintf(f,'########## Priors ##########\n');
fprintf(f,'For now, the only supported prior on lambda is a uniform on (0,1)\n');

fprintf(f,'########## Initial Parameters ##########\n');
fprintf(f,'lambda: %4.2f\n',lambda_init);

fprintf(f,'########## Proposal Densities ##########\n');
fprintf(f,'For now, the only supported lambda proposal density is a trunc. normal\n');
fprintf(f,'sigma = %4.2f with support on (%4.2f,%4.2f)\n',sigma_,a,b);

fprintf(f,'########## Other Specs ##########\n');
fprintf(f,'Number of draws: %i\n',N);
fprintf(f,'Burn in: %i\n',nb);

fclose(f);

f = fopen([resultsDir,spec_file,'.tex'],'w');

fprintf(f,'\\subsection{%s}\n',strrep(spec_file,'_','\_'));
fprintf(f,'\\label{sec:%s}\n',spec_file);
fprintf(f,'See results in section~\\ref{sec:%s_results}\n',spec_file);
fprintf(f,'\\verbatiminput{%s%s.txt}\n',dropboxDir,spec_file);
fprintf(f,'\\clearpage\n');

fclose(f);

ok = 1;
