function [ok] = figure_tex(resultsDir,dropbox_adj,fig_type)
ok = 0;
%% ------------------------------------------------------------------------
% Get spec
% -------------------------------------------------------------------------
spec_file = regexp(resultsDir,'(?<=/)(LR_|R_)?spec[0-9]*(?=/)','match');

if isempty(spec_file)
    error(['figure_tex.m not set up to handle: ',resultsDir]);
end

spec_file = spec_file{1};

%% ------------------------------------------------------------------------
% Dropbox folder
% -------------------------------------------------------------------------
tmp = regexp(resultsDir,'^\w+(?=/.*)','match');
dropboxDir = strrep(resultsDir,tmp{1},dropbox_adj);


%% ------------------------------------------------------------------------
% Get list of figures
% -------------------------------------------------------------------------
[rc list_fig] = system(['ls ',resultsDir,' | grep .',fig_type]);
list_fig      = strrep(list_fig,['.',fig_type],'.png');
list_fig      = regexp(list_fig,'\n','split');
list_fig      = list_fig(~cellfun(@(x) strcmp('',x),list_fig));

[~,~,env] = script_wrap_fn(spec_file,{},{'recursive'});
if ~isempty(env)
    eval([env{1}{1},' = env{1}{2};']);
end
set_captions;

tex_cue = {};
tex_cue_ind = [];

f = fopen([resultsDir,'figures.tex'],'w');

fprintf(f,'\\subsection{%s}\n',strrep(spec_file,'_','\_'));
fprintf(f,'\\label{sec:%s_results}\n',spec_file);
fprintf(f,'Go back to the specifications in section~\\ref{sec:%s}\n',spec_file);

for j_ = 1:length(list_fig)
    
    tmp0   = cellfun(@(x) regexp(list_fig{j_},['^',x],'match'),fig_name,'UniformOutput',0);
    ind0   = find(cellfun(@(x) ~isempty(x),tmp0));
    tmp0   = cellfun(@(x) x{1},tmp0(ind0),'UniformOutput',0);
    
    if length(ind0) > 1
        
        [ind2,tmp2] = elicit_file_name(ind0,tmp0,list_fig{j_});
        
        while length(ind2) > 1
            [ind2,tmp2] = elicit_file_name(ind2,tmp2,list_fig{j_});
        end
        
        ind = ind2;
        
    else
        ind = ind0;
    end
    
    if ~isempty(ind)
        
        if iscell(fig_caption{ind})
            if regexp(resultsDir,'LR_spec')
                caption = fig_caption{ind}{2};
            else
                caption = fig_caption{ind}{1};
            end
        else
            caption = fig_caption{ind};
        end
        
        ind_add = 0;
        
        if ~isempty(regexp(list_fig{j_},'semicond', 'once')) && ~isempty(regexp(list_fig{j_},'lamforward', 'once'))
            caption = [caption,' [semiconditional, $\\lambda_{t|t-h}$]'];
            ind_add = 1;
        elseif ~isempty(regexp(list_fig{j_},'semicond', 'once')) 
            caption = [caption,' [semiconditional]'];
        elseif ~isempty(regexp(list_fig{j_},'lamforward', 'once'))
            caption = [caption,' [$\\lambda_{t|t-h}$]'];
            ind_add = 1;
        end
        
        tex_tmp = sprintf('\\n\\n\\\\begin{figure}[h!]\\n');
        tex_tmp = [tex_tmp,sprintf('\\\\caption{%s}\\n',caption)];
        tex_tmp = [tex_tmp,sprintf('\\\\label{%s_%s}\\n',spec_file,fig_name{ind})];
        tex_tmp = [tex_tmp,sprintf('\\\\begin{center}\\n')];
        tex_tmp = [tex_tmp,sprintf('\\\\begin{tabular}{@{\\\\hspace*{-0cm}}c}\\n')];
        tex_tmp = [tex_tmp,sprintf('\\\\includegraphics[%s]{%s%s}\\n',fig_view{ind},dropboxDir,list_fig{j_})];
        tex_tmp = [tex_tmp,sprintf('\\\\\\\\ \\\\\\\\ \\n')];
        tex_tmp = [tex_tmp,sprintf('\\\\end{tabular}\\n')];
        tex_tmp = [tex_tmp,sprintf('\\\\end{center}\\n')];
        tex_tmp = [tex_tmp,sprintf('\\\\end{figure}\\n')];
        
        tex_cue{end+1} = tex_tmp;
        tex_cue_ind(end+1) = 10*ind+ind_add;
        
    end
end

[~,idx] = sort(tex_cue_ind);

for i_ = 1:length(idx)
    ind = idx(i_);
    fprintf(f,tex_cue{ind});
end

fprintf(f,'\\clearpage\n');
fclose(f);
ok = 1;
end

function [ind2,tmp2] = elicit_file_name(ind0,tmp0,list_fig)
    tmp1 = cellfun(@(x) regexp(x,'(?<=\w+_)([a-zA-z0-9]+)(?=.*)','match'),tmp0,'UniformOutput',0);
    
    ind1 = ind0(cellfun(@(x) ~isempty(x),tmp1));
    tmp1 = cellfun(@(x) x{1},tmp1(cellfun(@(x) ~isempty(x),tmp1)),'UniformOutput',0);
    
    tmp2 = cellfun(@(x) regexp(list_fig,['(?<=\w+_)',x],'match'),tmp1,'UniformOutput',0);
    tmp2 = cellfun(@(x) x{1},tmp2(cellfun(@(x) ~isempty(x),tmp2)),'UniformOutput',0);
    ind2 = ind1(cellfun(@(x) ~isempty(x),tmp2));
end

