%% ------------------------------------------------------------------------
% spec04.m: specify prior and pmmh proposal distributions for model 
% specification 04
% -------------------------------------------------------------------------

%% number of parameters
para_names   = {'sigma2'};
k            = length(para_names);

%% Prior specification
prior_spec   = {{'sigma2','IG',1,4}};
          
%% Proposal specification
prop_spec    = {{'sigma2','TrN',[0.5,0,Inf]}};
            
%% Parameter support
support_spec = {{'sigma2',[0,Inf]}};
         
%% Initial parameter values
para_init    = [1];

%% Fixed parameters
fixed_spec   = {{'rho',0.7}};

%% Other specifications
N            = 10000;
G_in         = 1;
K_in         = 5000;
fK_in        = 0.67;
nb           = 1000;

testName     = 'output_and_inflation_annualized';
semicond     = 1;

save_results = 1;