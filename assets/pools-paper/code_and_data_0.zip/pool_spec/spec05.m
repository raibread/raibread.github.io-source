%% ------------------------------------------------------------------------
% spec05.m: specify prior and pmmh proposal distributions for model 
% specification 05
% -------------------------------------------------------------------------

%% number of parameters
para_names   = {'rho','mu'};
k            = length(para_names);

%% Prior specification
prior_spec   = {{'rho','U'};...
                {'mu','N',[0,0],[0.75,1]}};
          
%% Proposal specification
prop_spec    = {{'rho','TrN',[0.15,0,1]};...
                {'mu','N',0.5}};
            
%% Parameter support
support_spec = {{'rho',[0,1]};...
                {'mu',[-Inf,Inf]}};
         
%% Initial parameter values
para_init    = [0.5,0];

%% Fixed parameters
fixed_spec   = {};

%% Other specifications
N            = 10000;
G_in         = 1;
K_in         = 5000;
fK_in        = 0.67;
nb           = 1000;

testName     = 'output_and_inflation_annualized';
semicond     = 1;

save_results = 1;