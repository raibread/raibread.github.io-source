% 1) Perform full sample Bayesian inference on parameters that determine the law of 
%    motion of the particles (i.e. transformed model weights) and the filtered 
%    sequence of dynamic model weights.

start;                  % set necessary paths
spec04;                 % choose prior distribution, proposal distribution, number of particles, etc.
parameter_inference;	% run full sample inference on law of motion parameters and filtered weights.

% 2) Perform recursive inference of parameters and filtered model weights at 
%    each time period t.

start;                      % set necessary paths
R_spec04;               	% choose prior distribution, proposal distribution, number of particles, etc.
nCap = 1;     	            % OPTIONAL: choose number of cores if running in parallel.
recursive_inference;     	% runs parameter_inference.m recursively (and in parallel if nCap > 1).

% 3) Perform recursive inference under static model weight assumption

start;                      % set necessary paths
LR_spec01;              	% choose prior distribution, proposal distribution, number of particles, etc.
lambda_recursive;        	% runs pmmh.m recursively (not set up for parallel evaluation).