%% ------------------------------------------------------------------------
% lamfcast.m: input is lambda_{t-h|t-h}, output is lambda_{t|t-h}
% -------------------------------------------------------------------------
function [l_f] = lamfcast(l_h,r,h)

if any(size(r) ~= [1 1])
    r = repmat(r,size(l_h)./size(r));
end
l_f = nan(size(l_h));
l_f = normcdf(r.^h.*norminv(l_h,0,1),0,1);