function [ok] = parse_spec(resultsDir,dropbox_adj)
ok = 0;

spec_file = regexp(resultsDir,'(?<=/)(LR_|R_)?spec[0-9]*(?=/)','match');
spec_file = spec_file{1};
eval([spec_file,';']);

f = fopen([resultsDir,spec_file,'.txt'],'w');

fprintf(f,'########## Model Spec: %s ##########\n\n',spec_file);

fcast_type = '';
if strcmp(testName,'output_and_inflation_annualized')
    fcast_type = [fcast_type,'4Q gdp and inf.'];
elseif strcmp(testName,'output_and_inflation')
    fcast_type = [fcast_type,'1Q gdp and inf.'];
else
    error(['predictive density ',testName,' not supported']);
end

if semicond
    fcast_type = [fcast_type,' (semiconditional)'];
end

fprintf(f,'Predictive density: %s\n',fcast_type);
fprintf(f,'########## Directories ##########\n');
fprintf(f,'Results directory: %s\n',resultsDir);

tmp = regexp(resultsDir,'^\w+(?=/.*)','match');
dropboxDir = strrep(resultsDir,tmp{1},dropbox_adj);
fprintf(f,'Dropbox directory: %s\n',dropboxDir);


fprintf(f,'########## Parameters to be estimated ##########\n');
for i_ = 1:k
    if i_~=k
        fprintf(f,'%s, ',para_names{i_});
    else
        fprintf(f,'%s\n',para_names{i_});
    end
end

fprintf(f,'########## Priors ##########\n');

for j_ = 1:k
    name_tmp = prior_spec{j_}{1};
    type_tmp = prior_spec{j_}{2};
    
    if strcmp(type_tmp,'U')
        fprintf(f,'%s: uniform prior on (%4.2f,%4.2f)\n',...
            name_tmp,support_spec{j_}{2});
    elseif strcmp(type_tmp,'IG')
        fprintf(f,'%s: inv. gamma prior with df = %i and mu = %4.2f\n',...
            name_tmp,prior_spec{j_}{4},prior_spec{j_}{3});
    elseif strcmp(type_tmp,'B')
        fprintf(f,'%s: beta prior with mu = %4.2f and sigma = %4.2f\n',...
            name_tmp,prior_spec{j_}{3},prior_spec{j_}{4});
    elseif strcmp(type_tmp, 'N')
        fprintf(f,'%s: normal prior with ',name_tmp);
        
        if prior_spec{j_}{3}(2)
            fprintf(f,'mu = invcdf(%4.2f) and ',prior_spec{j_}{3}(1));
        else
            fprintf(f,'mu = %4.2f and ',prior_spec{j_}{3}(1));
        end
        
        if prior_spec{j_}{4}(2)
            fprintf(f,'sigma = invcdf(%4.2f)\n',prior_spec{j_}{4}(1));
        else
            fprintf(f,'sigma = %4.2f\n',prior_spec{j_}{4}(1));
        end
    else
        error(['prior type ',type_tmp,' not supported.']);
    end
end

fprintf(f,'########## Proposal Densities ##########\n');

for m_ = 1:k
    name_tmp = prop_spec{m_}{1};
    type_tmp = prop_spec{m_}{2};
   
    if strcmp(type_tmp,'N')
        fprintf(f,'%s: normal with sigma = %4.2f\n',...
            name_tmp,prop_spec{m_}{3});
    elseif strcmp(type_tmp,'TrN')
        fprintf(f,'%s: trunc. normal with sigma = %4.2f and support on (%4.2f,%4.2f)\n',...
            name_tmp,prop_spec{m_}{3});
    else
        error(['proposal type ',type_tmp,' not supported.']);
    end
end
fprintf(f,'########## Initial Parameters ##########\n');
for l_ = 1:k
    if l_ == k
        fprintf(f,'%s: %4.2f\n',para_names{l_},para_init(l_));
    else
        fprintf(f,'%s: %4.2f, ',para_names{l_},para_init(l_));
    end
end

fprintf(f,'########## Fixed Parameters ##########\n');
fprintf(f,'(By default if not estimated or explicitly fixed, rho=0.5, mu=0 and sigma2 = 1)\n');
for k_ = 1:length(fixed_spec)
    fprintf(f,'%s: %4.2f\n',fixed_spec{k_}{1},fixed_spec{k_}{2});
end

fprintf(f,'########## Other Specs ##########\n');
fprintf(f,'Number of draws: %i\n',N);
fprintf(f,'Burn in: %i\n',nb);

fprintf(f,'Number of particles: %i\n',K_in);
fprintf(f,'ESS: %4.2f\n',fK_in);
fprintf(f,'Number of groups (for diagnostics only): %i\n',G_in);
    
fclose(f);

f = fopen([resultsDir,spec_file,'.tex'],'w');

fprintf(f,'\\subsection{%s}\n',strrep(spec_file,'_','\_'));
fprintf(f,'\\label{sec:%s}\n',spec_file);
fprintf(f,'See results in section~\\ref{sec:%s_results}\n',spec_file);
fprintf(f,'\\verbatiminput{%s%s.txt}\n',dropboxDir,spec_file);
fprintf(f,'\\clearpage\n');

fclose(f);

ok = 1;
