function [b,hout,xout] = bar2(X,bin_rule,lims)

% length of data series
N = length(X);

% check limits
if ~exist('lims','var')
    lims = [min(X) max(X)];
else
    if lims(1) == -Inf
        lims = [min(X) lims(2)];
    end
    
    if lims(2) == Inf
        lims = [lims(1) max(X)];
    end
end

% check bin width rule
if strcmp(bin_rule,'scott')
    b_width = (3.5*std(X))*(N^(-1/3));
    nbin    = ceil(diff(lims)/b_width);
elseif strcmp(bin_rule,'fre-dia')
    b_width = 2*iqr(X)*N^(-1/3);
    nbin    = ceil(diff(lims)/b_width);
else
    error('supported bin width rules: ''scott'' and ''fre-dia''');
end

ctr = lims(1) + [0:nbin-1]*b_width + b_width/2;

% generate bin counts
[ct,xout] = hist(X,ctr);
% normalize bar height
hout      = ct/(N*b_width);
% plot bar chart
b         = bar(xout,hout,1);
xlim(lims);