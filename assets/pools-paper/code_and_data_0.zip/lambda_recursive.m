%% ------------------------------------------------------------------------
% lambda_recursive.m: recursively runs through sample estimating static
% lambda
% -------------------------------------------------------------------------
% AUTHOR: Raiden B. Hasegawa
% ECONOMIST: Marco Del Negro
% DATE: 2014-03-03
% -------------------------------------------------------------------------

%% ------------------------------------------------------------------------
% Set parameters
% -------------------------------------------------------------------------

if ~exist('spec_file','var')
    spec_file = 'LR_spec01';
end
eval(spec_file);
test = testVars(testName,{},semicond);

%% ------------------------------------------------------------------------
% load predictive densities
% -------------------------------------------------------------------------

% if semi-conditional, change save file names
if semicond             
  p_string='_semicond'; 
else
  p_string='';
end

f904 = fopen(['densities/predictive_density_means_904_10-Jan-1992_to_10-Apr-2011_',testName,p_string],'r');
f805 = fopen(['densities/predictive_density_means_805_10-Jan-1992_to_10-Apr-2011_',testName,p_string],'r');
p904 = fread(f904,'single');
p805 = fread(f805,'single');

% get date series
fd904 = fopen(['densities/predictive_density_fdates_904_10-Jan-1992_to_10-Apr-2011_',testName,p_string],'r');
dt    = fread(fd904,'single');
T = size(dt,1);

lRep = nan(N,T);
rejRep = nan(1,T);

%% ------------------------------------------------------------------------
% Reorganize parameters of input functions
% -------------------------------------------------------------------------
prior_fcn   = @(x) 1;
prop_fcn    = @(mu,a,b,sigma) rtnorm(a,b,mu,sigma);
propPr_fcn  = @(x,y,a,b,sigma) rtnormpdf(x,a,b,y,sigma);   

%% ------------------------------------------------------------------------
% Argument lists for functions being passed to pmmh(...)
% -------------------------------------------------------------------------

prior_args  = {};
prop_args   = {a,b,sigma_};
propPr_args = prop_args;

%% ------------------------------------------------------------------------
% Run PMMH algorithm recursively
% -------------------------------------------------------------------------
tic;

for t_ = 1:T
    logLik_args = {p904(1:t_,1),p805(1:t_,1)};
    
    [draws_lam,~,rej_prct] = pmmh(prior_fcn,@logLikStatic,prop_fcn,...
        propPr_fcn,lambda_init,N,prior_args,logLik_args,prop_args,propPr_args);
    
    lRep(:,t_) = draws_lam;
    rejRep(1,t_) = rej_prct;
end

%% ------------------------------------------------------------------------
% Save Results
% -------------------------------------------------------------------------
if save_results
    %% --------------------------------------------------------------------
    % Set file name suffix
    % ---------------------------------------------------------------------
    save_suffix = [testName,'_N',num2str(N),'_sigma',...
       num2str(100*sigma_),'_lambdaInit',num2str(100*lambda_init),p_string];
   
    %% --------------------------------------------------------------------
    % Set directory
    % ---------------------------------------------------------------------
    
    % spec specific directory
    resultsDir = ['results/',spec_file,'/'];
    
    % semiconditional subdirectory
    if semicond
        resultsDir = [resultsDir,'semicond/'];
    end
    
    % dated directory
    resultsDir = [resultsDir,datestr(now,'YYYYmmdd-HHMMSS'),'/'];
    if ~exist(resultsDir,'dir')
        mkdir(resultsDir);
    end
    
    %% --------------------------------------------------------------------
    % save draws
    % ---------------------------------------------------------------------
    
    % lambda_t
    f = fopen([resultsDir,'draws_lam_',save_suffix],'w');
    fwrite(f,lRep,'single');
    fclose(f);
    
    % rejection percentage
    f = fopen([resultsDir,'rej_prct_',save_suffix],'w');
    fwrite(f,rejRep,'single');
    fclose(f);
    
    %% --------------------------------------------------------------------
    % Burn baby burnnnnn
    % ---------------------------------------------------------------------
    lRep   = lRep(nb+1:end,:);
    
    %% --------------------------------------------------------------------
    % Plot 2d distributions, weight evolution, log score, etc.
    % ---------------------------------------------------------------------
    wRep = ones(size(lRep))/(N-nb);
    
    plotResults;
    
    %% --------------------------------------------------------------------
    % histogram evolution (filtered lambda)
    % ---------------------------------------------------------------------
    f = figure();
    
    % generate histogram evolution with freedman-diaconis bin width rule
    hist_out = hist_evol(lRep,dt+test.k*0.25,[0,1],'fre-dia');

    hgsave(f,[resultsDir,'Histogram_Evol_SP_',save_suffix,'.fig']);
    
    %% --------------------------------------------------------------------
    % Make these .fig files .png files!!!
    % ---------------------------------------------------------------------
    [rc list_fig] = system(['ls ',resultsDir,' | grep .fig']);
        list_fig = regexp(list_fig,'\n','split');
        for j_ = 1:length(list_fig)
            tmp_file = [resultsDir,list_fig{j_}];
            if exist(tmp_file,'file') && ~strcmp(list_fig{j_},'')
                h = hgload(tmp_file);
                print(h,'-r300','-dpng',strrep(tmp_file,'.fig','.png'));
                system(['rm ',tmp_file]);
            end
        end
    
    %% --------------------------------------------------------------------
    % save spec file
    % ---------------------------------------------------------------------
    ok1 = parse_LR_spec(resultsDir,'figures');
    ok2 = figure_tex(resultsDir,'figures','png');
    
end
