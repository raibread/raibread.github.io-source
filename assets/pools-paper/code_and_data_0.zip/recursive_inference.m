%% ------------------------------------------------------------------------
% recursive_inference.m: estimate parameters recursively
% -------------------------------------------------------------------------

%% ------------------------------------------------------------------------
% Set parameters
% -------------------------------------------------------------------------
if ~exist('spec_file','var')
    spec_file = 'R_spec01';
end
eval(spec_file);
test = testVars(testName,{},semicond);

%% ------------------------------------------------------------------------
% load predictive densities
% -------------------------------------------------------------------------

% if semi-conditional, change save file names
if semicond             
  p_string='_semicond'; 
else
  p_string='';
end

f904 = fopen(['densities/predictive_density_means_904_10-Jan-1992_to_10-Apr-2011_',testName,p_string],'r');
f805 = fopen(['densities/predictive_density_means_805_10-Jan-1992_to_10-Apr-2011_',testName,p_string],'r');
p904 = fread(f904,'single');
p805 = fread(f805,'single');

% get date series
fd904 = fopen(['densities/predictive_density_fdates_904_10-Jan-1992_to_10-Apr-2011_',testName,p_string],'r');
dt    = fread(fd904,'single');

T = length(dt);

%% ------------------------------------------------------------------------
% recursive estimation
% -------------------------------------------------------------------------

if exist('nCap','var') && nCap ~= 1
    nMax = min(T,nCap);
    eval(['matlabpool ',num2str(nMax),';']);
end

err = cell([T 1]);
env = cell([T 1]);
ok  = nan([T 1]);

parfor i_ = 1:T
    list_args = {'parameter_inference',...
	['start;','spec_file = ''',spec_file,'''; T = ',num2str(i_),...
        '; set(0,''DefaultFigureVisible'',''off'')'],...
        {'draws_para','draws_lam','rej_prct','draws_LL','draws_pri'}};
    
    [ok(i_),err{i_},env{i_}] = script_wrap_fn(list_args{:});
end

if exist('nMax','var')
    matlabpool close;
end

if any(cellfun(@(x) ~isempty(x),err))
    error('One of your parallel runs ate it big time... check the err variable for more info!');
end

%% ------------------------------------------------------------------------
% join results
% -------------------------------------------------------------------------

draws_para = NaN([N k T]);
draws_lam  = NaN([N T]);
rej_prct   = NaN([1 T]);
draws_LL   = NaN([N T]);
draws_pri  = NaN([N T]);

for j_ = 1:T
    
    for k_ = 1:length(env{j_})
        if strcmp(env{j_}{k_}{1},'draws_para')
            tmp = '(:,:,';
        else
            tmp = '(:,';
        end
        
        eval([env{j_}{k_}{1},tmp,num2str(j_),') = env{',num2str(j_),'}{',num2str(k_),'}{2};']);
    end
end

clear env;
    
%% ------------------------------------------------------------------------
% Save Results
% -------------------------------------------------------------------------
set(0,'DefaultFigureVisible','off');

if save_results_master
    %% --------------------------------------------------------------------
    % Set file name suffix
    % ---------------------------------------------------------------------
    save_suffix = [testName,'_N',num2str(N),'_G',num2str(G_in),'_K',...
        num2str(K_in),'_ESS',num2str(100*fK_in),'_',spec_file,p_string];
    
    %% --------------------------------------------------------------------
    % Set directory
    % ---------------------------------------------------------------------
    
    % spec specific directory
    resultsDir = ['results/',spec_file,'/'];
    
    % semiconditional subdirectory
    if semicond
        resultsDir = [resultsDir,'semicond/'];
    else
        resultsDir = [resultsDir,'uncond/'];
    end
    
    % dated directory
    resultsDir = [resultsDir,datestr(now,'YYYYmmdd-HHMMSS'),'/'];
    if ~exist(resultsDir,'dir')
        mkdir(resultsDir);
    end
    
    %% --------------------------------------------------------------------
    % save draws
    % ---------------------------------------------------------------------
    for i_ = 1:k
        f = fopen([resultsDir,'draws_',para_names{i_},'_',save_suffix],'w');
        
        fwrite(f,squeeze(draws_para(:,i_,:)),'single');
        fclose(f);
    end
    
    % lambda_t
    f = fopen([resultsDir,'draws_lam_',save_suffix],'w');
    fwrite(f,draws_lam,'single');
    fclose(f);
    
    % log likelihood
    f = fopen([resultsDir,'draws_LL_',save_suffix],'w');
    fwrite(f,draws_LL,'single');
    fclose(f);
    
    % log prior
    f = fopen([resultsDir,'draws_pri_',save_suffix],'w');
    fwrite(f,draws_pri,'single');
    fclose(f);
    
    % rejection percentage
    f = fopen([resultsDir,'rej_prct_',save_suffix],'w');
    fwrite(f,rej_prct,'single');
    fclose(f);
    
    %% --------------------------------------------------------------------
    % Burn baby burnnnnn
    % ---------------------------------------------------------------------
    draws_para = draws_para(nb+1:end,:,:);
    draws_lam  = draws_lam(nb+1:end,:);
    draws_LL   = draws_LL(nb+1:end,:);
    draws_pri  = draws_pri(nb+1:end,:);
    
    %% --------------------------------------------------------------------
    % Map mu to lambda space 
    % ---------------------------------------------------------------------
    i_mu = find(cell2mat(cellfun(@(x) strcmp('mu',x{1}),...
        prior_spec,'UniformOutput',0)));
    if ~isempty(i_mu)
        draws_para(:,i_mu,:) = normcdf(draws_para(:,i_mu,:));
        support_spec{i_mu}{2} = normcdf(support_spec{i_mu}{2});
    end
    
    %% --------------------------------------------------------------------
    % save marginal parameter density plot (evolution over time)
    % ---------------------------------------------------------------------
    
    for i1 = 1:k
        fig = figure();
        
        % adjust histogram bounds for parameters with inf. support
        tmp_support = support_spec{i1}{2};
        if tmp_support(1) == -Inf
            tmp_support(1) = min(min(draws_para(:,i1,:)));
        end
        if tmp_support(2) == Inf
            tmp_support(2) = max(max(draws_para(:,i1,:)));
        end
        
        % generate histogram evolution with freedman-diaconis bin width ru
        hist_out = hist_evol(squeeze(draws_para(:,i1,:)),dt + test.k*0.25,tmp_support,'fre-dia',1,50);
        
        % save
        hgsave(fig,[resultsDir,'HISTOGRAM_draws_',...
            para_names{i1},'_',save_suffix,'.fig']);
    end
    
    %% --------------------------------------------------------------------
    % Plot 2d distributions, weight evolution, log score, etc.
    % ---------------------------------------------------------------------
    lRep = draws_lam;
    wRep = ones(size(lRep))*1/(N-nb);
    
    plotResults;
    plotResults2;
    
    %% --------------------------------------------------------------------
    % histogram evolution (filtered lambda)
    % ---------------------------------------------------------------------
    fig = figure();
    
    % generate histogram evolution with freedman-diaconis bin width rule
    hist_out = hist_evol(draws_lam,dt,[0,1],'fre-dia',0);
    
    if max(zlim) > 30
        zlim([0 30]);
    end
    
    % save
    hgsave(fig,[resultsDir,'HISTOGRAM_evol_',save_suffix,'.fig']);
    
    %% --------------------------------------------------------------------
    % Make these .fig files .png files!!!
    % ---------------------------------------------------------------------
    [rc list_fig] = system(['ls ',resultsDir,' | grep .fig']);
        list_fig = regexp(list_fig,'\n','split');
        for j_ = 1:length(list_fig)
            tmp_file = [resultsDir,list_fig{j_}];
            if exist(tmp_file,'file') && ~strcmp(list_fig{j_},'')
                h = hgload(tmp_file);
                print(h,'-r300','-dpng',strrep(tmp_file,'.fig','.png'));
                system(['rm ',tmp_file]);
            end
        end
    
    %% --------------------------------------------------------------------
    % save spec file
    % ---------------------------------------------------------------------
    ok1 = parse_spec(resultsDir,'figures');
    ok2 = figure_tex(resultsDir,'figures','png');
end

