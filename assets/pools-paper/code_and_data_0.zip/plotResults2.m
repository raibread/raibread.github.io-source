%% ------------------------------------------------------------------------
% Define some necessary variables if undefined
% -------------------------------------------------------------------------
if ~exist('predCombine','var')
    predCombine = @(l,p1,p2) l.*p1+ (1-l).*p2;
end

if ~exist('T','var')
    T = length(dt);
end

if exist('rho','var')
    rhoRep = rho;
else
    i1 = find(cell2mat(cellfun(@(x) strcmp('rho',x{1}),...
        prior_spec,'UniformOutput',0)));
    i2 = find(cell2mat(cellfun(@(x) strcmp('rho',x{1}),...
        fixed_spec,'UniformOutput',0)));

    if ~isempty(i1)
        if size(draws_para,3) == 1;
            rhoRep = draws_para(:,i1);
        elseif size(draws_para,3) > 1
            rhoRep = squeeze(draws_para(:,i1,:));
        end
    elseif ~isempty(i2)
        rhoRep = fixed_spec{i2}{2};
    end
end

%% ------------------------------------------------------------------------
% Get filtered predictive densities
% -------------------------------------------------------------------------
lRep = lamfcast(lRep,rhoRep,test.k);

filtPredDens = predCombine(lRep(:,1:size(lRep,2)-test.k)',...
    repmat(p904(test.k+1:end,1),[1,(N-nb)]),repmat(p805(test.k+1:end,1),[1,(N-nb)]));

%% ------------------------------------------------------------------------
% log posterior predictive densities (black: pooled, red: SW+Inf+FF, blue:
% SW+Inf)
% -------------------------------------------------------------------------
if exist('bolMode','var') && bolMode
    qtile = 0.5;
    
    [tmpLm,ix_tmp] = sort(lRep',2);
    tmpWm = cumsum(wRep(ix_tmp')',2);
    mnLRep = nan(size(lRep',1),1);
    
    for k = 1:size(mnLRep,1)
        j = 1;
        while tmpWm(k,j) < qtile
            j = j + 1;
        end
        mnLRep(k,1) = tmpLm(k,j);
    end
    forplot1 = log(predCombine(mnLRep(1:end-test.k,1),...
        p904(test.k+1:end,1),p805(test.k+1:end,1)));
    
    [tmpFiltPredDens,ix_tmp_2] = sort(filtPredDens,2);
    tmpWm_2 = cumsum(wRep(ix_tmp_2')',2);
    forplot = nan(size(filtPredDens,1),1);
    
    for k = 1:size(forplot,1)
        j = 1;
        while tmpWm_2(k,j) < qtile
            j = j + 1;
        end
        forplot(k,1) = log(tmpFiltPredDens(k,j));
    end
    
else
    forplot  = sum(wRep(:,1:size(lRep,2)-test.k)'.*log(filtPredDens),2); % E[log(...)]
    mnLRep = sum(wRep.*lRep,1)'; % E_(w)t[lambda_t]
    forplot1 = log(predCombine(mnLRep(1:end-test.k,1),p904(test.k+1:end,1),...
        p805(test.k+1:end,1))); % log(E[...])    
end

f1 = figure();

plot(dt(1+test.k:end),log(p805(test.k+1:end,1)),'b-','LineWidth',1.5);
hold on;
plot(dt(1+test.k:end),log(p904(test.k+1:end,1)),'r-','LineWidth',1.5);
plot(dt(1+test.k:end),forplot1,'k-','LineWidth',2);

xlim([dt(1+test.k) dt(end)]);
pbaspect([2 1 1]);

print(f1,'-r300','-dpng',[resultsDir,'logPostPredDens','_',save_suffix,'_lamforward.png'])

%% ------------------------------------------------------------------------
% log posterior predictive densities differences (red: SW+Inf+FF - pooled,
% blue: SW+Inf - pooled)
% -------------------------------------------------------------------------
f1a = figure();

diff805 = forplot1 - log(p805(test.k+1:end,1));
diff904 = forplot1 - log(p904(test.k+1:end,1));

fill805 = fill([dt(1+test.k:end);flipud(dt(1+test.k:end))],...
    [diff805;zeros(size(diff805))],'b');
set(fill805,'EdgeColor','k','FaceAlpha',0.5,'EdgeAlpha',0.5);

hold on;

fill904 = fill([dt(1+test.k:end);flipud(dt(1+test.k:end))],...
    [diff904;zeros(size(diff904))],'r');
set(fill904,'EdgeColor','k','FaceAlpha',0.5,'EdgeAlpha',0.5);

xlim([dt(1+test.k) dt(end)]);
pbaspect([2 1 1]);

hgsave(f1a,[resultsDir,'logPostPredDens_deviations',...
    '_',save_suffix,'_lamforward.fig'])

%% ------------------------------------------------------------------------
% BMA v. optimal static weights v. dynamic filtered weights
% -------------------------------------------------------------------------
% dynamic filtered weights
wDynamic = mnLRep;

% BMA weights
rec904 = cumprod(p904);
rec805 = cumprod(p805);
wBma = rec904./(rec904+rec805);

% Static weights
wStatic = nan(T,1);
for t = 1:T
    staticLS = @(w) -sum(log(w*p904(1:t,1)+ (1-w)*p805(1:t,1)),1);
    wStatic(t,1) = fminbnd(staticLS,0,1);
end
%% ------------------------------------------------------------------------
% equally weighted v. BMA v. optimal static weights v. dynamic filtered 
% log predictive
% -------------------------------------------------------------------------
bmaPredDens = predCombine(wBma(1:end-test.k,1),p904(test.k+1:end,1),...
    p805(test.k+1:end,1));

staticPredDens = predCombine(wStatic(1:end-test.k,1),...
    p904(test.k+1:end,1),p805(test.k+1:end,1));

f4 = figure();

diffBMA = forplot1 - log(bmaPredDens);
diffStat = forplot1 - log(staticPredDens);

logEWP = log(predCombine(0.5,p904(test.k+1:end,1),p805(test.k+1:end,1)));

diffEWP = forplot1 - logEWP;

fillBMA = fill([dt(1+test.k:end);flipud(dt(1+test.k:end))],...
    [diffBMA;zeros(size(diffBMA))],rgb('DarkGreen'));
set(fillBMA,'EdgeColor',rgb('DarkGreen'),'FaceAlpha',0.5,'EdgeAlpha',0.5);

hold on;

fillStat = fill([dt(1+test.k:end);flipud(dt(1+test.k:end))],...
    [diffStat;zeros(size(diffStat))],rgb('DarkViolet'));
set(fillStat,'EdgeColor',rgb('DarkViolet'),'FaceAlpha',0.3,'EdgeAlpha',0.3);

plot(dt(1+test.k:end),diffEWP,'k-','LineWidth',1.5);

xlim([dt(1+test.k) dt(end)]);
pbaspect([2 1 1]);

hgsave(f4,[resultsDir,'dynamicVSstaticVSbma_logPostPredDens',...
    '_',save_suffix,'_lamforward.fig'])

%% ------------------------------------------------------------------------
% Table: Cumulative Log Score
% -------------------------------------------------------------------------
f = fopen([resultsDir,'cumLogScoreTable','_',save_suffix,'_lamforward.tex'],'w');

fprintf(f,'\\begin{table}[here]\n');
fprintf(f,'\\caption{Cumulative Log Scores}\n');
fprintf(f,'\\label{t_cumLS}\n');
fprintf(f,'\\begin{center}\n');

fprintf(f,'\\vspace*{-1cm}\n');
fprintf(f,'\\begin{tabular}{cc@{\\hspace*{1cm}}cc} \\\\ \\hline\\hline\n');
fprintf(f,['\\multicolumn{2}{l}{Component Models} &',...
    ' \\multicolumn{2}{l}{Model Pooling} \\\\ \\hline \n']);
fprintf(f,'Model & Log score & Method & Log score \\\\ \\hline \n');
fprintf(f,'SW$\\pi$ & %0.2f & BMA & %0.2f \\\\ \n',...
    sum(log(p805(test.k+1:end,1))),sum(log(bmaPredDens)));
fprintf(f,'SWFF & %0.2f & SP & %0.2f \\\\ \n',...
    sum(log(p904(test.k+1:end,1))),sum(log(staticPredDens)));
fprintf(f,' &  & EW & %0.2f \\\\ \n',sum(logEWP));
fprintf(f,' &  & DP & %0.2f \\\\ \\hline \\hline \n',sum(forplot1));
fprintf(f,'\\end{tabular}\n');
fprintf(f,'\\end{center}\n');
fprintf(f,'\\end{table}\n');
fclose(f);


