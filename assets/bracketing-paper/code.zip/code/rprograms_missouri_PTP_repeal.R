# Analysis of Missouri's repeal of its handgun PTP law using bracketing
#
# The following code produces the results of the primary results found in
# Tables 1 and 2 in S3 of the main text, Table 1 in the supplemental materials,
# and two additional figures comparing time series of firearm homicide rates in
# Misourri to lower, upper and all controls.
#
# NOTE: All data comes directly from the CDC Wonder system.

library(ggplot2)
yearseq=1999:2016
missouri=c(4.4,4.9,4.9,4.5,3.9,4.5,5.2,5.1,4.6,6.2,5.5,5.8,5.2,5.4,5.1,5.7,8,8.1)
borderstates=c(4.3,4.4,4.3,4.3,4.2,3.9,4.1,4.1,4.1,4.3,4.2,3.8,4.1,4.4,4,4.1,4.8,6.1)
combined.homicides=c(missouri,borderstates)
combined.year=rep(yearseq,2)
group=c(rep("Missouri",18),rep("Border States",18))
tempdf=data.frame(combined.homicides,combined.year,group)
events=data.frame(combined.year.events=2007)
ggplot(tempdf,aes(x=combined.year,y=combined.homicides,group=group))+geom_line(aes(linetype=group),size=2)+scale_linetype_manual(values=c("dashed", "dotted","twodash"))+labs(x="Year",y="Gun Homicide Rate")+geom_vline(data=events,aes(xintercept=combined.year.events))+geom_text(x=2007,y=.5,label="Repeal")+coord_cartesian(ylim = c(0, 8.5))+guides(fill = guide_legend(keywidth = 1, keyheight = 1),
                                                                                                                                                                                                                                                                                                                                                           linetype=guide_legend(keywidth = 3.9, keyheight = 1))


# Rates in Missouri
missouri.pre=4.7
missouri.pre.se=.1
missouri.post=6.1
missouri.post.se=.1
border.pre=4.3
border.pre.se=.05
border.post=4.4
border.post.se=.05
se.diff.in.diff=sqrt(missouri.pre.se^2+missouri.post.se^2+border.pre.se^2+border.post.se^2)
lower.control.pre=2.7
lower.control.pre.se=.05
lower.control.post=3.2
lower.control.post.se=.05
upper.control.pre=5.2
upper.control.pre.se=.1
upper.control.post=5.3
upper.control.post.se=.1

# Make plot with the lower controls and the upper controls
lower.controls=c(2.9,2.8,2.7,2.5,2.6,2.8,2.7,2.7,2.8,3.1,2.8,2.6,2.9,3.2,3,2.8,3.8,4.5)
upper.controls=c(5.2,5.5,5.5,5.6,5.3,4.7,5.1,5.2,5,5.1,5.2,4.6,4.9,5.2,4.8,5,5.6,7.2)
combined.homicide.rate=c(missouri,lower.controls,upper.controls)
combined.year=rep(yearseq,3)
group=c(rep("Missouri",18),rep("Lower Control",18),rep("Upper Control",18))
tempdf=data.frame(combined.homicide.rate,combined.year,group)
ggplot(tempdf,aes(x=combined.year,y=combined.homicide.rate,group=group))+geom_line(aes(linetype=group),size=2)+scale_linetype_manual(values=c("dashed", "dotted","twodash"))+labs(x="Year",y="Gun Homicide Rate")+geom_vline(data=events,aes(xintercept=combined.year.events))+geom_text(x=2007,y=.5,label="Repeal")+coord_cartesian(ylim = c(0,8.5))+guides(fill = guide_legend(keywidth = 1, keyheight = 1),
         linetype=guide_legend(keywidth = 3.9, keyheight = 1))

# Standard error for difference-in-difference
missouri.pre=4.7
missouri.pre.se=.1
missouri.post=6.1
missouri.post.se=.1
border.pre=4.2
border.pre.se=.05
border.post=4.4
border.post.se=.05
se.diff.in.diff=sqrt(missouri.pre.se^2+missouri.post.se^2+border.pre.se^2+border.post.se^2)
diff.in.diff=(missouri.post-border.post)-(missouri.pre-border.pre)
percent.change.est=100*diff.in.diff/(missouri.pre+border.post-border.pre)
percent.change.est
var.percent.change=100^2*(1/(missouri.pre+border.post-border.pre))^2*se.diff.in.diff^2+(diff.in.diff^2/((missouri.pre+border.post-border.pre)^4))*(missouri.pre.se^2+border.pre.se^2+border.post.se^2)-2*(diff.in.diff/((missouri.pre+border.post-border.pre)^3))*(-missouri.pre.se^2-border.pre.se^2-border.post.se^2)
sqrt(var.percent.change)

lower.control.pre=2.7
lower.control.pre.se=.05
lower.control.post=3.2
lower.control.post.se=.05
upper.control.pre=5.2
upper.control.pre.se=.1
upper.control.post=5.3
upper.control.post.se=.1

# Post data from only 2008-2013
missouri.post=5.5
missouri.post.se=.1
lower.control.post=2.9
lower.control.post.se=.1
upper.control.post=5
upper.control.post.se=.1

# Lower control estimates
se.diff.in.diff=sqrt(missouri.pre.se^2+missouri.post.se^2+lower.control.pre.se^2+lower.control.post.se^2)
diff.in.diff=(missouri.post-lower.control.post)-(missouri.pre-lower.control.pre)
percent.change.est=100*diff.in.diff/(missouri.pre+lower.control.post-lower.control.pre)
percent.change.est
var.percent.change=100^2*(1/(missouri.pre+lower.control.post-lower.control.pre))^2*se.diff.in.diff^2+(diff.in.diff^2/((missouri.pre+lower.control.post-lower.control.pre)^4))*(missouri.pre.se^2+lower.control.pre.se^2+lower.control.post.se^2)-2*(diff.in.diff/((missouri.pre+lower.control.post-lower.control.pre)^3))*(-missouri.pre.se^2-lower.control.pre.se^2-lower.control.post.se^2)
sqrt(var.percent.change)

# Upper control estimates
se.diff.in.diff=sqrt(missouri.pre.se^2+missouri.post.se^2+upper.control.pre.se^2+upper.control.post.se^2)
diff.in.diff=(missouri.post-upper.control.post)-(missouri.pre-upper.control.pre)
percent.change.est=100*diff.in.diff/(missouri.pre+upper.control.post-upper.control.pre)
percent.change.est
var.percent.change=100^2*(1/(missouri.pre+upper.control.post-upper.control.pre))^2*se.diff.in.diff^2+(diff.in.diff^2/((missouri.pre+upper.control.post-upper.control.pre)^4))*(missouri.pre.se^2+upper.control.pre.se^2+upper.control.post.se^2)-2*(diff.in.diff/((missouri.pre+upper.control.post-upper.control.pre)^3))*(-missouri.pre.se^2-upper.control.pre.se^2-upper.control.post.se^2)
sqrt(var.percent.change)

