library(tidyverse)
# This should be set to the directory in which you have put
# the uncompressed contents of the code.zip folder.
setwd("~/Bracketing/code/")

# These data files come directly from the CDC Wonder system
pre_df  <- read_tsv("all_states_pre_period.txt")
main_df <- read_tsv("all_states_before_after_periods.txt")

# Source: https://github.com/ubikuity/List-of-neighboring-states-for-each-US-state
neighbor_states <- read_csv("neighbors-states.csv")
state_abbr      <- read_csv("usa-states.csv")

# Map state codes to state names
state_map <- state_abbr %>%
  inner_join(neighbor_states, by = "StateCode") %>%
  inner_join(state_abbr, by = c("NeighborStateCode" = "StateCode")) %>%
  dplyr::select(State = StateName.x,
                NeighborState = StateName.y)

# Helper functions to remove CDC Wonder annotations
rm_notes <- function(.data, col_name) {
  q_col_name <- enquo(col_name)
  data.out <- .data %>% 
    filter(is.na((!! q_col_name))) %>% 
             dplyr::select(-one_of(as.character(q_col_name)[-1]))
  return(data.out)
}

find_annotations <- function(.data, col_name, ann_pattern) {
  q_col_name <- enquo(col_name)
  data.out <- .data %>% mutate(Annotated = grepl(ann_pattern,(!! q_col_name)))
}

clean_annotations <- function(pattern, x) {
  trimws(regmatches(x, regexpr(pattern,x)))
}

pre_clean  <- pre_df %>% rm_notes(Notes)
main_clean <- main_df %>% rm_notes(Notes) 
all_clean  <- bind_rows(pre_clean,main_clean) 

names(all_clean) <- gsub("%","pct",gsub(" ","_",names(all_clean)))

# Assign state-years to period
all_clean <- all_clean %>% 
  find_annotations(Age_Adjusted_Rate,"Unreliable")%>%
  mutate(Period = case_when(
    Year > 1993 & Year <= 1998 ~ "Pre",
    Year > 1998 & Year <= 2007 ~ "Before",
    Year > 2007 & Year <= 2016 ~ "After"))

all_clean <- all_clean %>% 
  mutate(Age_Adjusted_Rate = as.numeric(clean_annotations('^[^ ]+',Age_Adjusted_Rate)),
         Crude_Rate = as.numeric(clean_annotations('^[^ ]+',Crude_Rate)))

# Remove AK, HI and DC from analysis
agg_df <- all_clean %>%
  filter(!(State %in% c("Alaska","Hawaii","District of Columbia")))

pop_wtd_mean <- function(x,pop) {
  return(sum(x * pop)/sum(pop))
}

# Primary function to compute bracketed difference in difference estimates
#   - The function finds neighbor states, classifies them as upper or lower
#     controls based on the Pre period, and returns bracketing estimate
#   - When there are only upper or only lower controls, the function returns
#     only the available side of the bracketing estimate.
bracketed_DiD <- function(tr_st, st_map, agg_rate) {
  control_st <- c(filter(st_map,State == tr_st)[["NeighborState"]],
                  filter(st_map,NeighborState == tr_st)[["State"]])
  
  pre_tr <- filter(agg_rate, State == tr_st & Period == "Pre")
  tr_agg_rate <- pop_wtd_mean(pre_tr$Age_Adjusted_Rate,pre_tr$Population)
  
  after_tr  <- filter(agg_rate, State == tr_st & Period == "After")
  before_tr <- filter(agg_rate, State == tr_st & Period == "Before")
  
  tr_diff   <- pop_wtd_mean(after_tr$Age_Adjusted_Rate,after_tr$Population) -
    pop_wtd_mean(before_tr$Age_Adjusted_Rate,before_tr$Population)
  
  
  pre_agg <- filter(agg_rate, State %in% control_st & Period == "Pre") %>%
    group_by(State,Period) %>%
    summarize(Age_Adjusted_Rate_Mean = pop_wtd_mean(Age_Adjusted_Rate,Population))
    
  pre_agg <- pre_agg %>% 
    transmute(Upper_Lower = case_when(Age_Adjusted_Rate_Mean < tr_agg_rate ~ "Lower",
                                      Age_Adjusted_Rate_Mean >=  tr_agg_rate ~ "Upper"))
  
  tmp_main <- filter(agg_rate, State %in% control_st & Period %in% c("Pre","Before","After")) %>%
    inner_join(pre_agg,"State")
  
  pop_wtd_diff <- function(df,U_L) {
    df_before <- filter(df,Period == "Before", Upper_Lower == U_L) 
    df_after  <- filter(df,Period == "After", Upper_Lower == U_L) 
    
    return(sum(df_after[["Age_Adjusted_Rate"]]*df_after[["Population"]])
           /sum(df_after[["Population"]]) - 
             sum(df_before[["Age_Adjusted_Rate"]]*df_before[["Population"]])
           /sum(df_before[["Population"]]))
  }
  
  out_mat <- matrix(c(round(tr_diff,1) - round(pop_wtd_diff(tmp_main,"Lower"),1),
                      round(tr_diff,1) - round(pop_wtd_diff(tmp_main,"Upper"),1)), 
                    ncol = 2)
  
  colnames(out_mat) <- c("Lower_Control_DiD","Upper_Control_DiD")
  out_tbl <- as.tibble(out_mat) %>% mutate(Treated_State = tr_st)
  
  return(out_tbl)
}

# Apply bracketing to each state with neighbors and complete data
#   - DiD yields two placebo effect randomization distributions,
#     one using difference-in-difference with lower controls and 
#     and one using upper controls
DiD <- bind_rows(
  lapply(setdiff(state_abbr[["StateName"]],
                 c("Alaska","Hawaii","North Dakota","South Dakota","Vermont","District of Columbia")),
         function(s) bracketed_DiD(s,state_map,agg_df))
  )

# The following code computes

# Figure 1: Right Panel
hist(DiD$Upper_Control_DiD, breaks = 15, 
     main = "Upper Control Placebo Study",
     xlab = "Upper Control DiD Estimates")
abline(v = DiD$Upper_Control_DiD[DiD$Treated_State == "Missouri"],
       col = 'red')
# Figure 2: Left Panel
hist(DiD$Lower_Control_DiD, breaks = 15, 
     main = "Lower Control Placebo Study",
     xlab = "Lower Control DiD Estimates")
abline(v = DiD$Lower_Control_DiD[DiD$Treated_State == "Missouri"],
       col = 'red')


# Falsification Tests and figures for visual inspection of relative trends
before_clean <- all_clean %>% 
  mutate(Period = case_when(Year >= 1999 & Year <= 2002 ~ "Before",
                            Year > 2002 & Year <= 2007 ~ "After")) %>%
  filter(!is.na(Period))

# Control and treatment groups
uc_names <- c("Arkansas","Illinois","Tennessee")
lc_names <- c("Iowa","Kansas","Kentucky","Nebraska","Oklahoma")
tr_name  <- c("Missouri")

before_clean <- before_clean %>% 
  filter(State %in% c(lc_names,uc_names,tr_name)) %>%
  mutate(UL = case_when(State %in% lc_names ~ "LC",
                        State %in% tr_name ~ "T",
                        State %in% uc_names ~ "UC"))


pop_wtd_sd <- function(sd,pop) {
  sqrt(sum(sd**2 * pop**2)/sum(pop)**2)
}

# get population weighted firearm homicide rates and standard errors by 
# group and period.
false_agg <- before_clean %>% group_by(Period,UL) %>% 
  summarize(sd = pop_wtd_sd(Age_Adjusted_Rate_Standard_Error,Population),
            mean = pop_wtd_mean(Age_Adjusted_Rate,Population))

# Function to return difference in differnce estimate and standard error
DiD_t <- function(df,g1,g2) {
  tmp_g1 <- df %>% filter(UL == g1)
  tmp_g2 <- df %>% filter(UL == g2)

  return(list("DiD"=((tmp_g1$mean[tmp_g1$Period == "After"] - tmp_g1$mean[tmp_g1$Period == "Before"]) -
            (tmp_g2$mean[tmp_g2$Period == "After"] - tmp_g2$mean[tmp_g2$Period == "Before"])),
            "SD"= sqrt(sum(tmp_g1$sd**2+tmp_g2$sd**2))))
}

# Testing alternative pattern (iii) [(a) and (b)]
# p-value for (iii)(a)
did.a <- DiD_t(false_agg,"UC","T")
p.val.a <- pnorm(did.a$DiD/did.a$SD,lower.tail = FALSE)

# p-value for (iii)(b)
did.b <- DiD_t(false_agg,"T","LC")
p.val.b <- pnorm(did.b$DiD/did.b$SD,lower.tail = TRUE)

# Function to compute error bars in Supplemental Figure 1
error_bars <- function(df_agg,per,ul,clr = 'black') {
  x <- ifelse(per == "Before",0,1)
  lines(c(x,x),c(df_agg$mean[df_agg$Period == per & df_agg$UL == ul] - 
                   1.96*df_agg$sd[df_agg$Period == per & df_agg$UL == ul],
                 df_agg$mean[df_agg$Period == per & df_agg$UL == ul] +
                   1.96*df_agg$sd[df_agg$Period == per & df_agg$UL == ul]), 
        col = clr)
  points(c(x,x),c(df_agg$mean[df_agg$Period == per & df_agg$UL == ul] - 
                    1.96*df_agg$sd[df_agg$Period == per & df_agg$UL == ul],
                  df_agg$mean[df_agg$Period == per & df_agg$UL == ul] +
                    1.96*df_agg$sd[df_agg$Period == per & df_agg$UL == ul]), 
         col = clr,pch = '_')
}

# Supplemental Figure 1 (Left Panel)
# DiD effect plot (1999-2002 (early part of Before) vs. 2003-2007 (later part of Before))
plot(mean~I(Period=="After"),filter(false_agg,UL == "T"),
     type='l',lty = 2, ylim = c(2.5,6.5), xlim = c(-0.15,1.15),
     xaxt = 'n',xlab = 'Period',ylab = 'Rate')
Axis(side = 1, at = c(0,1),labels = c("1999-2002","2003-2007"))
lines(mean~I(Period=="After"),filter(false_agg,UL == "LC"),
      col='red',lty=2)
lines(mean~I(Period=="After"),filter(false_agg,UL == "UC"),
      col='blue',lty=2)

error_bars(false_agg,"Before","T")
error_bars(false_agg,"After","T")

error_bars(false_agg,"Before","LC",clr='red')
error_bars(false_agg,"After","LC",clr='red')

error_bars(false_agg,"Before","UC",clr='blue')
error_bars(false_agg,"After","UC",clr='blue')

# Supplemental Figure 1 (Right Panel)
# DiD effect plot (1999-2007 (Before) vs. 2008-2016 (After))
all_clean_sub <- all_clean %>% 
  filter(State %in% c(lc_names,uc_names,tr_name) & Period != "Pre") %>%
  mutate(UL = case_when(State %in% lc_names ~ "LC",
                        State %in% tr_name ~ "T",
                        State %in% uc_names ~ "UC"))

all_agg_sub <- all_clean_sub %>% group_by(Period,UL) %>% 
  summarize(sd = pop_wtd_sd(Age_Adjusted_Rate_Standard_Error,Population),
            mean = pop_wtd_mean(Age_Adjusted_Rate,Population))

plot(mean~I(Period=="After"),filter(all_agg_sub,UL == "T"),
     type='l',lty = 2, ylim = c(2.5,6.5), xlim = c(-0.15,1.15),
     xaxt = 'n',xlab = 'Period',ylab = 'Rate')
Axis(side = 1, at = c(0,1),labels = c("1999-2007","2008-2016"))
lines(mean~I(Period=="After"),filter(all_agg_sub,UL == "LC"),
      col='red',lty=2)
lines(mean~I(Period=="After"),filter(all_agg_sub,UL == "UC"),
      col='blue',lty=2)

error_bars(all_agg_sub,"Before","T")
error_bars(all_agg_sub,"After","T")

error_bars(all_agg_sub,"Before","LC",clr='red')
error_bars(all_agg_sub,"After","LC",clr='red')

error_bars(all_agg_sub,"Before","UC",clr='blue')
error_bars(all_agg_sub,"After","UC",clr='blue')
