##########
##########
# Golf Analysis

tps1.data = read.csv("tps1.csv", header = TRUE)

tps1.data[which(tps1.data$Player.Last.Name == "Mickelson"),]

#
# Exercise 1.2.1
#
# The coordinate columns are given in feet.
# The columns show `0' when the ball is in the hole.
# The tee box is not given in coordinates,
# since the coordinates are from where the ball stops.


plot(tps1.data$X.Coordinate, tps1.data$Y.Coordinate)
dev.copy(png, "tps1_image_1.png")
dev.off()

#
# Exercise 1.2.2
#
tps1.nonzero = tps1.data[which(tps1.data$X.Coordinate != 0),]
plot(tps1.nonzero$X.Coordinate, tps1.nonzero$Y.Coordinate)
#
# We can clearly see the shots now.
# The right side of the plot is less concentrated; these are
# the tee shots and possibly poor second shots.
# The lower left is tightly concentrated, and this is the green.
#

#
# Exercise 1.2.3
#
unique(tps1.nonzero$Date)
#
# The above reveals four dates.
# The pin placement is changed on each day; so it's
# no wonder there are multiple tight clusters.

tps1.first.day = tps1.nonzero[which(tps1.nonzero$Date == "2/5/15"),]
tps1.second.day = tps1.nonzero[which(tps1.nonzero$Date == "2/6/15"),]
tps1.third.day = tps1.nonzero[which(tps1.nonzero$Date == "2/7/15"),]
tps1.fourth.day = tps1.nonzero[which(tps1.nonzero$Date == "2/8/15"),]

plot(tps1.first.day$X.Coordinate, tps1.first.day$Y.Coordinate)
plot(tps1.second.day$X.Coordinate, tps1.second.day$Y.Coordinate)
plot(tps1.third.day$X.Coordinate, tps1.third.day$Y.Coordinate)
plot(tps1.fourth.day$X.Coordinate, tps1.fourth.day$Y.Coordinate)



tps1.first.shot = tps1.data[which(tps1.data$Shot == 1),]
distance.yards = tps1.first.shot$Distance / 36
golf.model = lm(tps1.first.shot$Hole.Score ~ distance.yards)
plot(distance.yards, tps1.first.shot$Hole.Score)
abline(golf.model)
summary(golf.model)

dev.copy(png, "tps1_image_2.png")
dev.off()


#
# Exercise 1.3.1
#
newdata = data.frame(distance.yards = c(240, 280, 310))
predict(golf.model, newdata)
#
# 4.498010 4.179221 3.940130 
#

#
# Exercise 1.3.2
#
# For a linear model, we are assuming the Y_i have the distribution
# Y_i = N(b_0 + b_1 X_i, sigma^2).
# Further, the Y_i are independent.


#
# Exercise 1.3.3
#
# We could use average score on a hole as a function of 
# the average drive distance.
# We would want to only include par 4 and par 5 holes.
# Additionally, we would need assumptions necessary for a 
# central limit theorem.
# In particular, we need iid drives for a particular golfer.
# The bigger problem might be course layout.
# Based on the shape of the hole, golfers might do better or worse
# with their drives.
# We'll assume for now that this is okay.
#


#
# Exercise 1.4.1
#
full.round = read.csv("TorreyPinesSouth.csv")
length(unique(full.round$Player.First.Name))
length(unique(full.round$Player.Last.Name))
length(unique(full.round$Player..))
# The answers are 118, 150, and 155.

#
# Exercise 1.4.2
#
hole.scores = function(id.number, data.set = full.round){
     player.data = data.set[which(data.set$Player.. == id.number),]
     player.data.1 = player.data[which(player.data$Par.Value == 4),]
     player.data.2 = player.data.1[which(player.data.1$Shot == 1),]  
   
     return(player.data.2$Hole.Score)
}

drive.distances = function(id.number, data.set = full.round){
     player.data = data.set[which(data.set$Player.. == id.number),]
     player.data.1 = player.data[which(player.data$Par.Value == 4),]
     player.data.2 = player.data.1[which(player.data.1$Shot == 1),]  
   
     return(player.data.2$Distance / 36)
}


#
# Exercise 1.4.3
#
round.info = function(data.set = full.round){
     player.ids = unique(data.set$Player..)
     n = length(player.ids)
     scores = rep(0, n)
     distances = rep(0, n)
     
     for(i in (1 : n)){
          player = player.ids[i]
          scores[i] = mean(hole.scores(player))
          distances[i] = mean(drive.distances(player))

     }
     
     return(list(scores = scores, distances = distances))
}

#
# Exercise 1.4.4
#
average.model = lm(x$scores ~ x$distances)
plot(x$distances, x$scores)
abline(average.model)
dev.copy(png, "tp_1.png")
dev.off()

# The data looks more reasonable for a linear model, but
# there is still a lot of randomness that isn't captured by
# the drive distance.



