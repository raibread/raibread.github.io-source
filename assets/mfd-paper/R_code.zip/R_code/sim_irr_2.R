library(tidyverse)


set.seed(19)
k <- 7


# choose and load simulation setting
sim_setting <- k
source("sim_settings.R")
list2env(params,.GlobalEnv)

# n{zg} = number of individuals in study with Z=z and G=g
n00 <- ceiling((1-pVacc)*(1-pHbAS)*n)
n01 <- ceiling((1-pVacc)*pHbAS*n)
n10 <- ceiling(pVacc*(1-pHbAS)*n)
n11 <- ceiling(pVacc*pHbAS*n)

# calibrating generative parameters to acheive desired specificity and
# number of events per child-year
phi_   <- fev_per_ch_yr*(1-spec_)
kappa_ <- fev_per_ch_yr*spec_/((1-pHbAS)+nu_*pHbAS)

# load fever generating functions and estimation functions
source("sim_functions.R")

tau.pois.sim <- list()
s2.pois.sim <- list()

list2env(params,.GlobalEnv)

for(j in 1:n.tau) {
  tau_ <- tau.seq[j]
  tau.tmp <- matrix(rep(NA,n.sim*2),ncol=2)
  s2.tmp <- matrix(rep(NA,n.sim*2),ncol=2)
  
  for(i in 1:n.sim) {
    
    df <- data.frame(G = c(rep(0,n00),rep(1,n01),rep(0,n10),rep(1,n11)),
                     Z = c(rep(0,n00+n01),rep(1,n10+n11)),
                     X = rnorm(n))
    
    df$Y <- y_any(df$G,df$Z,df$X)
    
    mod.pois <- glm(Y ~ Z*G*X,data = df,family = poisson())
    
    tmp <- tau_pois(mod.pois,df,pHbAS,pVacc)
    tmp_0 <- tau_pois_0(mod.pois,df,pVacc)
    tau.tmp[i,] <- c(tmp$tau.hat,tmp_0$tau.hat)
    s2.tmp[i,]  <- c(tmp$s2.hat/n,tmp_0$s2.hat/n) 
    
  }
  tau.pois.sim[[j]] <- tau.tmp
  s2.pois.sim[[j]] <- s2.tmp
}
  
bias <- sapply(1:n.tau, function(i) f_prop_bias(tau.pois.sim[[i]][,1],tau.seq[i]))
rmse <- sapply(1:n.tau, function(i) f_rmse(tau.pois.sim[[i]][,1],tau.seq[i]))
cover <- sapply(1:n.tau, function(i) f_cover(tau.pois.sim[[i]][,1],s2.pois.sim[[i]][,1],tau.seq[i]))
pow <- sapply(1:n.tau, function(i) f_pow(tau.pois.sim[[i]][,1],s2.pois.sim[[i]][,1],tau.seq[i]))

bias_0 <- sapply(1:n.tau, function(i) f_prop_bias(tau.pois.sim[[i]][,2],tau.seq[i]))
rmse_0 <- sapply(1:n.tau, function(i) f_rmse(tau.pois.sim[[i]][,2],tau.seq[i]))
cover_0 <- sapply(1:n.tau, function(i) f_cover(tau.pois.sim[[i]][,2],s2.pois.sim[[i]][,2],tau.seq[i]))
pow_0 <- sapply(1:n.tau, function(i) f_pow(tau.pois.sim[[i]][,2],s2.pois.sim[[i]][,2],tau.seq[i]))

tau.bnd.sim <- lapply(1:n.tau, function(i) bnd_est(tau.pois.sim[[i]][,1],
                                                   tau.pois.sim[[i]][,2]-qnorm(1-0.001)*sqrt(s2.pois.sim[[i]][,2])))
bias_bnd <- sapply(1:n.tau, function(i) f_prop_bias(tau.bnd.sim[[i]],tau.seq[i]))
rmse_bnd <- sapply(1:n.tau, function(i) f_rmse(tau.bnd.sim[[i]],tau.seq[i]))
cover_bnd <- sapply(1:n.tau, function(i) f_cover_bnd(tau.pois.sim[[i]][,1],s2.pois.sim[[i]][,1],
                                                     tau.pois.sim[[i]][,2],s2.pois.sim[[i]][,2],
                                                     tau.seq[i],gam=0.001))
pow_bnd <- sapply(1:n.tau, function(i) f_pow_bnd(tau.pois.sim[[i]][,1],s2.pois.sim[[i]][,1],
                                                 tau.pois.sim[[i]][,2],s2.pois.sim[[i]][,2],
                                                 tau.seq[i],gam=0.001))

ci_len_bnd <- sapply(1:n.tau, function(i) f_ci_len_bnd(tau.pois.sim[[i]][,1],s2.pois.sim[[i]][,1],
                                                 tau.pois.sim[[i]][,2],s2.pois.sim[[i]][,2],
                                                 tau.seq[i],gam=0.001))

par(xpd=TRUE)
barplot(rbind(sapply(bias,function(x) min(1,x)),
              sapply(bias_0,function(x) min(1,x)),
              sapply(bias_bnd,function(x) min(1,x))),beside = T,names.arg = tau.seq,
        col = c(alpha("black",0.7),alpha("gray42",0.7),alpha("gray74",0.7)),
        ylab = "Proportional |Bias|")
title(xlab = expression(tau),cex.lab=1.5)
legend("top",inset=c(-0.15),c("MFD","naive","bounded"),pch=15,cex = 1.1,horiz = T,
       col = c(alpha("black",0.7),alpha("gray42",0.7),alpha("gray74",0.7)),bty="n",pt.cex=1.5)
arrows(x0 = seq(1.5,5.5,4),y0 = c(1.002,1.002), 
         x1 = seq(1.5,5.5,4), y1= c(1.05,1.05), col = 'gray', length = .1)

barplot(rbind(sapply(rmse,function(x) min(1,x)),
              sapply(rmse_0,function(x) min(1,x)),
              sapply(rmse_bnd,function(x) min(1,x))),beside = T,names.arg = tau.seq,
        col = c(alpha("black",0.7),alpha("gray42",0.7),alpha("gray74",0.7)),
        ylab = "RMSE")
title(xlab = expression(tau),cex.lab=1.5)
legend("top",inset=c(-0.15),c("MFD","naive","bounded"),pch=15,cex = 1.1,horiz = T,
       col = c(alpha("black",0.7),alpha("gray42",0.7),alpha("gray74",0.7)),bty="n",pt.cex=1.5)
arrows(x0 = seq(1.5,17.5,4),y0 = rep(1.002,5), 
       x1 = seq(1.5,17.5,4), y1= rep(1.05,5), col = 'gray', length = .1)


barplot(rbind(sapply(pow,function(x) min(1,x)),
              sapply(pow_0,function(x) min(1,x)),
              sapply(pow_bnd,function(x) min(1,x))),beside = T,names.arg = tau.seq,
        col = c(alpha("black",0.7),alpha("gray42",0.7),alpha("gray74",0.7)),
        ylab = "Power")
title(xlab = expression(tau),cex.lab=1.5)
legend("top",inset=c(-0.15),c("MFD","naive","bounded"),pch=15,cex = 1.1,horiz = T,
       col = c(alpha("black",0.7),alpha("gray42",0.7),alpha("gray74",0.7)),bty="n",pt.cex=1.5)

barplot(rbind(sapply(cover,function(x) min(1,x)),
              sapply(cover_0,function(x) min(1,x)),
              sapply(cover_bnd,function(x) min(1,x))),beside = T,names.arg = tau.seq,
        col = c(alpha("black",0.7),alpha("gray42",0.7),alpha("gray74",0.7)),
        ylab = "Coverage",ylim = c(0,1))
title(xlab = expression(tau),cex.lab=1.5)
legend("top",inset=c(-0.15),c("MFD","naive","bounded"),pch=15,cex = 1.1,horiz = T,
       col = c(alpha("black",0.7),alpha("gray42",0.7),alpha("gray74",0.7)),bty="n",pt.cex=1.5)
segments(x0 = 0.5,y0 = 0.95,x1 = 20,y1 = 0.95,lty=2,lwd=1.25)

