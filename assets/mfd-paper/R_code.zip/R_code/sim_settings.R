## Simulation Setting 1 (High Spec., Strong Mend. Factor):
# - 1.5 fevers per child year
# - 80% specificity
# - 1000 individuals in each arm
# - tau = (0.3,0.4,0.5,0.6,0.7)
# - HbAS protective efficacy (nu*100) = 50%
if(sim_setting == 1) {
  params <- list(
    # generative parameters
    spec_         = 0.8,
    fev_per_ch_yr = 1.5,
    nu_           = 0.5,
    
    # sequence of effects
    tau.seq = seq(0.3,0.7,0.1),
    n.tau   = length(seq(0.3,0.7,0.1)),
    
    # sample size, P(HbAS), P(Vacc)
    n     = 2000,
    pHbAS = 0.2,
    pVacc = 0.5,
    
    # simulation parameters
    n.sim = 5000)
}

## Simulation Setting 2 (Low Spec., Strong Mend. Factor):
# - 1.5 fevers per child year
# - 50% specificity
# - 1000 individuals in each arm
# - tau = (0.3,0.4,0.5,0.6,0.7)
# - HbAS protective efficacy (nu*100) = 50%
if(sim_setting == 2) {
  params <- list(
    # generative parameters
    spec_         = 0.5,
    fev_per_ch_yr = 1.5,
    nu_           = 0.5,
    
    # sequence of effects
    tau.seq = seq(0.3,0.7,0.1),
    n.tau   = length(seq(0.3,0.7,0.1)),
    
    # sample size, P(HbAS), P(Vacc)
    n     = 2000,
    pHbAS = 0.2,
    pVacc = 0.5,
    
    # simulation parameters
    n.sim = 5000)
}

## Simulation Setting 3 (High Spec., Weak Mend. Factor):
# - 1.5 fevers per child year
# - 80% specificity
# - 1000 individuals in each arm
# - tau = (0.3,0.4,0.5,0.6,0.7)
# - HbAS protective efficacy (nu*100) = 25%
if(sim_setting == 3) {
  params <- list(
    # generative parameters
    spec_         = 0.8,
    fev_per_ch_yr = 1.5,
    nu_           = 0.7,
    
    # sequence of effects
    tau.seq = seq(0.3,0.7,0.1),
    n.tau   = length(seq(0.3,0.7,0.1)),
    
    # sample size, P(HbAS), P(Vacc)
    n     = 2000,
    pHbAS = 0.2,
    pVacc = 0.5,
    
    # simulation parameters
    n.sim = 5000)
}

## Simulation Setting 4 (Low Spec., Weak Mend. Factor):
# - 1.5 fevers per child year
# - 50% specificity
# - 1000 individuals in each arm
# - tau = (0.3,0.4,0.5,0.6,0.7)
# - HbAS protective efficacy (nu*100) = 25%
if(sim_setting == 4) {
  params <- list(
    # generative parameters
    spec_         = 0.5,
    fev_per_ch_yr = 1.5,
    nu_           = 0.7,
    
    # sequence of effects
    tau.seq = seq(0.3,0.7,0.1),
    n.tau   = length(seq(0.3,0.7,0.1)),
    
    # sample size, P(HbAS), P(Vacc)
    n     = 2000,
    pHbAS = 0.2,
    pVacc = 0.5,
    
    # simulation parameters
    n.sim = 5000)
}

## Simulation Setting 5 (High Spec., Weak Mend. Factor, Larger Sample):
# - 1.5 fevers per child year
# - 80% specificity
# - 1000 individuals in each arm
# - tau = (0.3,0.4,0.5,0.6,0.7)
# - HbAS protective efficacy (nu*100) = 25%
if(sim_setting == 5) {
  params <- list(
    # generative parameters
    spec_         = 0.8,
    fev_per_ch_yr = 1.5,
    nu_           = 0.7,
    
    # sequence of effects
    tau.seq = seq(0.3,0.7,0.1),
    n.tau   = length(seq(0.3,0.7,0.1)),
    
    # sample size, P(HbAS), P(Vacc)
    n     = 5000,
    pHbAS = 0.2,
    pVacc = 0.5,
    
    # simulation parameters
    n.sim = 5000)
}

## Simulation Setting 6 (Low Spec., Weak Mend. Factor, Larger Sample):
# - 1.5 fevers per child year
# - 50% specificity
# - 2500 individuals in each arm
# - tau = (0.3,0.4,0.5,0.6,0.7)
# - HbAS protective efficacy (nu*100) = 25%
if(sim_setting == 6) {
  params <- list(
    # generative parameters
    spec_         = 0.5,
    fev_per_ch_yr = 1.5,
    nu_           = 0.7,
    
    # sequence of effects
    tau.seq = seq(0.3,0.7,0.1),
    n.tau   = length(seq(0.3,0.7,0.1)),
    
    # sample size, P(HbAS), P(Vacc)
    n     = 5000,
    pHbAS = 0.2,
    pVacc = 0.5,
    
    # simulation parameters
    n.sim = 5000)
}

## Simulation Setting 7 (Low Spec., Weak Mend. Factor, Larger Sample):
# - 1.5 fevers per child year
# - 50% specificity
# - 2500 individuals in each arm
# - tau = (0.3,0.4,0.5,0.6,0.7)
# - HbAS protective efficacy (nu*100) = 25%
if(sim_setting == 7) {
  params <- list(
    # generative parameters
    spec_         = 0.5,
    fev_per_ch_yr = 1.5,
    nu_           = 0.7,
    
    # sequence of effects
    tau.seq = seq(0.3,0.7,0.1),
    n.tau   = length(seq(0.3,0.7,0.1)),
    
    # sample size, P(HbAS), P(Vacc)
    n     = 1000,
    pHbAS = 0.2,
    pVacc = 0.5,
    
    # simulation parameters
    n.sim = 5000)
}


