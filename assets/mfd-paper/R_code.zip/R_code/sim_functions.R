## Fever generating functions
library(mvtnorm)

# generate malaria-attributable fevers
y_m <- function(u,g,z,x,Bg = 0.05,Bz = 0.05,Bx = 0.05, Bx0 = 0.05, size = 10) {
  n <- length(x)
  xg <- rnorm(n)
  xz <- rnorm(n)
  x0 <- rnorm(n)
  ym <- as.integer(qnbinom(u,size = size, mu = kappa_*exp(Bx0*x0-Bx0**2*0.5)*
                             exp(Bx*x-Bx**2*0.5)*
                             (nu_*exp(Bg*xg-Bg**2*0.5))^g*
                             ((1-tau_)*exp(Bz*xz-Bz**2*0.5))^z))
  return(ym)
}

# generate non-malaria fevers
y_nm <- function(u,x,Bx = 0.075, Bx0 = 0.05,size = 10) {
  n <- length(x)
  x0 <- rnorm(n)
  ynm <- as.integer(qnbinom(u,size = size, mu = phi_*
                              exp(Bx0*x0-Bx0**2*0.5)*
                              exp(Bx*x-Bx**2*0.5)))
  return(ynm)
}

# generate fevers of any cause
y_any <- function(g,z,x,
                  Bg = 0.05,Bz = 0.05,Bx = 0.05, size = 10,
                  Bx_ = 0.075,Bx0 = 0.1,size_ = 10,rho = -0.1) {
  n <- length(x)
  u <- pnorm(rmvnorm(n,sigma = matrix(c(1,rho,rho,1),ncol=2)))
  y <- y_m(u[,1],g,z,x,Bg,Bz,Bx,Bx0,size) + y_nm(u[,2],x,Bx_,Bx0,size_)
  return(y)
}


## TMLE estimation functions (MFD)

# generate counterfactual predictions
ct_fact <- function(df,z,g) {
  df$G <- g
  df$Z <- z
  return(predict(mod.pois,newdata = df,type = 'response'))
}

# compute influece function
inf_fun <- function(Y.pred,Y.1,Y.0,df,pG,pZ,flip = F) {
  if(flip) {
    df$Z <- 1-df$Z
    pZ   <- 1-pZ
  }
  
  inf.fun <- df$Z*((df$G/pG) - (1-df$G)/(1-pG))*(df$Y - Y.pred)/pZ
  inf.fun <- inf.fun + (Y.1 - Y.0) - (mean(Y.1)-mean(Y.0))
  return(inf.fun)
}

# compute EIF-based plug-in variance estimator
var_hat <- function(if.1,if.2,EY.1,EY.2) {
  sig2hat <- mean((if.1*(1/EY.2) - (EY.1/EY.2**2)*if.2)**2)
  return(sig2hat)
}

# compute estimated marginal treatment efficacy
tau_pois <- function(mod.pois,df,pG,pZ) {
  
  Y.pred <- predict(mod.pois,newdata = df,type = 'response')
  
  Y.11 <- ct_fact(df,1,1)
  Y.10 <- ct_fact(df,1,0)
  Y.01 <- ct_fact(df,0,1)
  Y.00 <- ct_fact(df,0,0)
  
  if.num <- inf_fun(Y.pred,Y.11,Y.10,df,pG,pZ)
  if.den <- inf_fun(Y.pred,Y.01,Y.00,df,pG,pZ,flip=T)
  
  s2.hat <- var_hat(if.num,if.den,mean(Y.11-Y.10),mean(Y.01-Y.00))
  
  X <- Y.01 - Y.00
  Y <- Y.11 - Y.10
  tau.pois <- 1 - mean(Y)/mean(X)
  
  return(list(tau.hat = tau.pois,
              s2.hat  = s2.hat,
              mu.1 = mean(Y),
              mu.2 = mean(X),
              s2.1 = mean(if.num**2),
              s2.2 = mean(if.den**2),
              cov.hat = mean(if.den*if.num)))
}


## TMLE estimation functions (Naive)

# generate counterfactual predictions
ct_fact_0 <- function(df,z) {
  df$Z <- z
  return(predict(mod.pois,newdata = df,type='response'))
}

# compute influece function
inf_fun_0 <- function(Y.pred,Y,df,pZ,flip = F) {
  if(flip) {
    df$Z <- 1-df$Z
    pZ   <- 1-pZ
  }
  
  inf.fun <- df$Z*(df$Y - Y.pred)/pZ
  inf.fun <- inf.fun + Y - mean(Y)
  return(inf.fun)
}

# compute estimated marginal treatment efficacy
tau_pois_0 <- function(mod.pois,df,pZ) {
  
  Y.pred <- predict(mod.pois,newdata = df,type = 'response')
  
  Y.1 <- ct_fact_0(df,1)
  Y.0 <- ct_fact_0(df,0)
  
  if.num <- inf_fun_0(Y.pred,Y.1,df,pZ)
  if.den <- inf_fun_0(Y.pred,Y.0,df,pZ,flip=T)
  
  s2.hat <- var_hat(if.num,if.den,mean(Y.1),mean(Y.0))

  tau.pois <- 1 - mean(Y.1)/mean(Y.0)
  
  return(list(tau.hat = tau.pois,
              s2.hat  = s2.hat))
}


## helper functions

# proportional bias
f_prop_bias <- function(t,d) abs(mean(t-d)/d)

# rmse
f_rmse <- function(t,d) sqrt(mean((t-d)**2))

# coverage
f_cover <- function(t,s2,d,alph = 0.05)
  mean(abs(t-d)/sqrt(s2)<=qnorm(1-alph/2))

f_cover_bnd <- function(t,s2,t0,s20,d,alph = 0.05, gam = alph/4)
  mean(mapply(min,1,t+sqrt(s2)*qnorm(1-alph/2)) >= d & mapply(max,t-sqrt(s2)*qnorm(1-alph/2+gam),
                                                         t0-sqrt(s20)*qnorm(1-gam)) <= d)
# CI length
f_ci_len <- function(t,s2,t0,s20,d,alph = 0.05, gam = 0.001)
  mean(mapply(min,1,t+sqrt(s2)*qnorm(1-alph/2)) - (t-sqrt(s2)*qnorm(1-alph/2)))

f_ci_len_bnd <- function(t,s2,t0,s20,d,alph = 0.05, gam = 0.001)
  mean(mapply(min,1,t+sqrt(s2)*qnorm(1-alph/2)) - mapply(max,t-sqrt(s2)*qnorm(1-alph/2+gam),
                                                         t0-sqrt(s20)*qnorm(1-gam)))

# power
f_pow <- function(t,s2,d,alph = 0.05)
  mean(t+sqrt(s2)*qnorm(alph/2) > 0)

f_pow_bnd <- function(t,s2,t0,s20,d,alph = 0.05, gam = alph/4)
  mean(mapply(min,1,t+sqrt(s2)*qnorm(1-alph/2)) < 0 | mapply(max,t-sqrt(s2)*qnorm(1-alph/2+gam),
                                                              t0-sqrt(s20)*qnorm(1-gam)) > 0)

# fieller
fieller = function(x.mean,y.mean,x.var,y.var,xy.cov,alph = 0.05, tau,n) {

  x.sd = sqrt(x.var/n)
  y.sd = sqrt(y.var/n)
  xy.cov = xy.cov/n
  
 
  if(y.mean < 0) {
    t1 <- ((1-tau)*y.mean - x.mean) + qnorm(1-alph)*sqrt(y.sd**2*(1-tau)**2+x.sd**2-2*(1-tau)*xy.cov) < 0
    t2 <- ((1-tau)*y.mean - x.mean) - qnorm(1-alph)*sqrt(y.sd**2*(1-tau)**2+x.sd**2-2*(1-tau)*xy.cov) > 0
    rej <- t1 | t2
  }
  
  if(y.mean > 0) {
    t1 <- ((1-tau)*y.mean - x.mean) + qnorm(1-alph)*sqrt(y.sd**2*(1-tau)**2+x.sd**2-2*(1-tau)*xy.cov) > 0
    t2 <- ((1-tau)*y.mean - x.mean) - qnorm(1-alph)*sqrt(y.sd**2*(1-tau)**2+x.sd**2-2*(1-tau)*xy.cov) < 0
    rej <- t1 | t2
  }
  
  rej
  
}


# bounded estimator
bnd_est <- function(t1,t2) mapply(function(x,y) min(1,max(x,y)),t1,t2)

