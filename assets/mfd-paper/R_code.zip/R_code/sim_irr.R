library(tidyverse)

set.seed(19)
n.settings <- 6

bias <- rmse <- cover <- pow <- matrix(rep(NA,5*6),ncol = 5)
bias_0 <- rmse_0 <- cover_0 <- pow_0 <- matrix(rep(NA,5*6),ncol = 5)

tau.draws <- list()
s2.draws  <- list()

for(k in 1:n.settings) {
  # choose and load simulation setting
  sim_setting <- k
  source("sim_settings.R")
  list2env(params,.GlobalEnv)
  
  # n{zg} = number of individuals in study with Z=z and G=g
  n00 <- ceiling((1-pVacc)*(1-pHbAS)*n)
  n01 <- ceiling((1-pVacc)*pHbAS*n)
  n10 <- ceiling(pVacc*(1-pHbAS)*n)
  n11 <- ceiling(pVacc*pHbAS*n)
  
  # calibrating generative parameters to acheive desired specificity and
  # number of events per child-year
  phi_   <- fev_per_ch_yr*(1-spec_)
  kappa_ <- fev_per_ch_yr*spec_/((1-pHbAS)+nu_*pHbAS)
  
  # load fever generating functions and estimation functions
  source("sim_functions.R")
  
  tau.pois.sim <- list()
  s2.pois.sim <- list()
  all.pois.sim <- list()
  
  list2env(params,.GlobalEnv)
  
  for(j in 1:n.tau) {
    tau_ <- tau.seq[j]
    tau.tmp <- matrix(rep(NA,n.sim*2),ncol=2)
    s2.tmp <- matrix(rep(NA,n.sim*2),ncol=2)
    all.tmp <- matrix(rep(NA,n.sim*5),ncol=5)
    
    for(i in 1:n.sim) {
      
      df <- data.frame(G = c(rep(0,n00),rep(1,n01),rep(0,n10),rep(1,n11)),
                       Z = c(rep(0,n00+n01),rep(1,n10+n11)),
                       X = rnorm(n))
      
      df$Y <- y_any(df$G,df$Z,df$X)
      
      mod.pois <- glm(Y ~ Z*G*X,data = df,family = poisson())
      
      tmp <- tau_pois(mod.pois,df,pHbAS,pVacc)
      tmp_0 <- tau_pois_0(mod.pois,df,pVacc)
      tau.tmp[i,] <- c(tmp$tau.hat,tmp_0$tau.hat)
      s2.tmp[i,]  <- c(tmp$s2.hat/n,tmp_0$s2.hat/n) 
      all.tmp[i,] <- c(tmp$mu.1,tmp$mu.2,tmp$s2.1,tmp$s2.2,tmp$cov.hat)
      
    }
    tau.pois.sim[[j]] <- tau.tmp
    s2.pois.sim[[j]] <- s2.tmp
    all.pois.sim[[j]] <- all.tmp
  }
  
  bias[k,] <- sapply(1:n.tau, function(i) f_prop_bias(tau.pois.sim[[i]][,1],tau.seq[i]))
  rmse[k,] <- sapply(1:n.tau, function(i) f_rmse(tau.pois.sim[[i]][,1],tau.seq[i]))
  cover[k,] <- sapply(1:n.tau, function(i) f_cover(tau.pois.sim[[i]][,1],s2.pois.sim[[i]][,1],tau.seq[i]))
  pow[k,] <- sapply(1:n.tau, function(i) f_pow(tau.pois.sim[[i]][,1],s2.pois.sim[[i]][,1],tau.seq[i]))
  
  bias_0[k,] <- sapply(1:n.tau, function(i) f_prop_bias(tau.pois.sim[[i]][,2],tau.seq[i]))
  rmse_0[k,] <- sapply(1:n.tau, function(i) f_rmse(tau.pois.sim[[i]][,2],tau.seq[i]))
  cover_0[k,] <- sapply(1:n.tau, function(i) f_cover(tau.pois.sim[[i]][,2],s2.pois.sim[[i]][,2],tau.seq[i]))
  pow_0[k,] <- sapply(1:n.tau, function(i) f_pow(tau.pois.sim[[i]][,2],s2.pois.sim[[i]][,2],tau.seq[i]))
  
  tau.draws[[k]] <- tau.pois.sim
  s2.draws[[k]]  <- s2.pois.sim
}

# bounded draws
tau.bnd.draws <- lapply(1:n.settings, function(i) lapply(1:n.tau, function(j) bnd_est(tau.draws[[i]][[j]][,1],
                                                                                      tau.draws[[i]][[j]][,2]-
                                                                                        qnorm(1-0.001)*sqrt(s2.draws[[i]][[j]][,2]))))
bias_bnd <- rmse_bnd <- cover_bnd <- pow_bnd <- matrix(rep(NA,5*6),ncol = 5)

for(j in 1:6){
  tau.bnd.sim <- tau.bnd.draws[[j]]
  tau.pois.sim <- tau.draws[[j]]
  s2.pois.sim <- s2.draws[[j]]
  bias_bnd[j,] <- sapply(1:n.tau, function(i) f_prop_bias(tau.bnd.sim[[i]],tau.seq[i]))
  rmse_bnd[j,]  <- sapply(1:n.tau, function(i) f_rmse(tau.bnd.sim[[i]],tau.seq[i]))
  cover_bnd[j,]  <- sapply(1:n.tau, function(i) f_cover_bnd(tau.pois.sim[[i]][,1],s2.pois.sim[[i]][,1],
                                                            tau.pois.sim[[i]][,2],s2.pois.sim[[i]][,2],
                                                            tau.seq[i],gam=0.001))
  pow_bnd[j,]  <- sapply(1:n.tau, function(i) f_pow_bnd(tau.pois.sim[[i]][,1],s2.pois.sim[[i]][,1],
                                                        tau.pois.sim[[i]][,2],s2.pois.sim[[i]][,2],
                                                        tau.seq[i],gam=0.001))
}

# making tables for the paper
library(xtable)
bias_all <- reduce(lapply(1:6,function(i)cbind(t(bias)[,i],t(bias_0)[,i])),cbind)
bias_all <- rbind(bias_all[,1:4],bias_all[,5:8],bias_all[,9:12])
rmse_all <- reduce(lapply(1:6,function(i)cbind(t(rmse)[,i],t(rmse_0)[,i])),cbind)
rmse_all <- rbind(rmse_all[,1:4],rmse_all[,5:8],rmse_all[,9:12])
bias_rmse_all <- cbind(c(0.5,NA,NA,NA,NA,0.3,NA,NA,NA,NA,0.3,NA,NA,NA,NA),rep(c(0.3,0.4,0.5,0.6,0.7),3),
                     bias_all[,1:2],rep(NA,15),rmse_all[,1:2],rep(NA,15),bias_all[,3:4],rep(NA,15),rmse_all[,3:4])

print(xtable(bias_rmse_all),include.rownames = FALSE)


pow_all <- reduce(lapply(1:6,function(i)cbind(t(pow)[,i],t(pow_0)[,i])),cbind)
pow_all <- rbind(pow_all[,1:4],pow_all[,5:8],pow_all[,9:12])
cover_all <- reduce(lapply(1:6,function(i)cbind(t(cover)[,i],t(cover_0)[,i])),cbind)
cover_all <- rbind(cover_all[,1:4],cover_all[,5:8],cover_all[,9:12])
pow_cov_all <- cbind(c(0.5,NA,NA,NA,NA,0.3,NA,NA,NA,NA,0.3,NA,NA,NA,NA),rep(c(0.3,0.4,0.5,0.6,0.7),3),
                     cover_all[,1:2],rep(NA,15),pow_all[,1:2],rep(NA,15),cover_all[,3:4],rep(NA,15),pow_all[,3:4])

print(xtable(pow_cov_all),include.rownames = FALSE)

s <- 4
tau.pois.sim <- tau.draws[[s]]
tau.bnd.sim  <- tau.bnd.draws[[s]]
k <- 3
dat <- data_frame(tau = c(tau.pois.sim[[k]][,2],tau.pois.sim[[k]][,1],tau.bnd.sim[[k]]),
                  estimator = c(rep("Naive",5000),rep("MFD",5000),rep("Bnd",5000)))
ggplot(data = dat,
       aes(x = tau)) + 
  xlim(quantile(tau.pois.sim[[k]][,1],probs = c(0.01,0.99))) +
  geom_density(data = subset(dat,estimator == "MFD"),linetype = 0,
                 alpha = 0.4,fill = "#000000",na.rm=T) +
  geom_density(data = subset(dat,estimator == "Naive"),linetype = 0,
                 alpha = 0.5,fill = "#4682B4",na.rm=T) +
  geom_density(data = subset(dat,estimator == "Bnd"),linetype = 0,
               alpha = 0.5,fill = "#3CBC71",na.rm=T) +
  geom_vline(xintercept = mean(subset(dat,estimator == "MFD")$tau),
             lty = 3,alpha = 0.6,lwd=1.25) +
  geom_vline(xintercept = mean(subset(dat,estimator == "Naive")$tau),
             lty = 2, color = "#4682B4",lwd=1.25) +
  geom_vline(xintercept = tau.seq[k], color = 'black',lwd=0.8) +
  geom_vline(xintercept = mean(tau.bnd.sim[[k]]), lty = 4, color = "#3CBC71",lwd=1.25) +
  xlab(expression(tau)) +
  theme(axis.title = element_text(size = 16),
        axis.text = element_text(size = 16))

draws.by.setting <- list()
tau.seq <- c(0.3,0.4,0.5,0.6,0.7)
for(i in 1:n.settings) {
  tmp.draws <- data.frame(
    estimate = as.vector(reduce(tau.draws[[i]],rbind)),
    tau = rep(as.vector(sapply(tau.seq,function(x) rep(x,n.sim))),2),
    estimator = as.factor(c(rep("MFD",n.sim*n.tau),rep("Naive",n.sim*n.tau))),
    setting = as.factor(rep(as.character(i),n.sim*n.tau*2))
  )
  draws.by.setting[[i]] <- tmp.draws
}

all.draws <- reduce(draws.by.setting,rbind)

tau.stats <- all.draws %>% group_by(tau,estimator,setting) %>%
  summarize(middle = median(estimate),
            middle2 = mean(estimate),
            ymin  = quantile(estimate,0.05),
            ymax  = quantile(estimate,0.95),
            lower = quantile(estimate,0.25),
            upper = quantile(estimate,0.75),
            nsamp = ifelse(first(setting) %in% c(5,6),"n=5000","n=2000"))

ggplot(filter(tau.stats,tau %in% c(0.3,0.5,0.7)),
       aes(x=setting:estimator,fill = nsamp)) +
  geom_boxplot(aes(ymin = ymin, ymax = ymax,
                   middle = middle, upper = upper,
                   lower= lower), show.legend = NA,
               stat = 'identity', lwd = 0.25, alpha = 0.4) +
  geom_abline(aes(slope = 0, intercept = tau,alpha = 0.3),linetype = 2,show.legend = F) +
  geom_point(aes(x=setting:estimator,y=middle2, color = nsamp), shape = 18, size = 3, show.legend = F) +
  ylab(label = "estimate") +
  xlab(label = "") +
  theme_bw() +
  theme(legend.title = element_blank(), legend.position="bottom", legend.text = element_text(size=12),
        axis.text = element_text(size=12),axis.title = element_text(size=12)) +
  coord_flip() +
  facet_wrap(~tau,ncol=3,scales = "free_x")

########## TESTING #############

k <- 4
j <- 1
q <- quantile((tau.draws[[k]][[j]][,1]-mean(tau.draws[[k]][[j]][,1]))/
                sqrt(s2.draws[[k]][[j]][,1]),c(0.025,0.975))

qqnorm((tau.draws[[k]][[j]][,1]-mean(tau.draws[[k]][[j]][,1]))/
         sqrt(s2.draws[[k]][[j]][,1]))
qqline((tau.draws[[k]][[j]][,1]-mean(tau.draws[[k]][[j]][,1]))/
  sqrt(s2.draws[[k]][[j]][,1]))
hist((tau.draws[[k]][[j]][,1]-mean(tau.draws[[k]][[j]][,1]))/
       sqrt(s2.draws[[k]][[j]][,1]))

plot(density((tau.draws[[k]][[j]][,1]-mean(tau.draws[[k]][[j]][,1]))/
               sqrt(s2.draws[[k]][[j]][,1])))

fieller.CIs <- list()
for(j in 1:n.tau) {
  tmp.c <- rep(NA,n.sim)
  tmp.p <- rep(NA,n.sim)
  tmp.inc <- rep(NA,n.sim)
  for(i in 1:n.sim) {
    x <- all.pois.sim[[j]][i,]
    tmp.c[i] <- !fieller(x[1],x[2],x[3],x[4],x[5],tau = tau.seq[j],n = n,alp=0.025)
    tmp.p[i] <- fieller(x[1],x[2],x[3],x[4],x[5],tau = 0,n = n,alph=0.025)
  }
    
  
  
  fieller.CIs[[j]] <- c(mean(tmp.c,na.rm=T),mean(tmp.p,na.rm=T))
}
fieller.CIs
