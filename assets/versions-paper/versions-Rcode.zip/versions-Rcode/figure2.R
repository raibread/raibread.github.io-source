

plot.ci <- function(ci, y.pos, tick.size = 0.1, lty = 1,...) {
  segments(x0 = ci[1], x1 = ci[2],
           y0 = y.pos, y1 = y.pos, lty = lty,...)
  
  segments(x0 = ci[1], x1 = ci[1],
           y0 = y.pos - tick.size/2, 
           y1 = y.pos + tick.size/2, lty = 1,...)
  
  segments(x0 = ci[2], x1 = ci[2],
           y0 = y.pos - tick.size/2, 
           y1 = y.pos + tick.size/2, lty = 1,...)
}

plot(x=1,y=1, pch = NA, 
     xaxt = "n", xlab = "",
     xlim = c(-2,2), ylim = c(0,2),
     yaxt = "n", ylab = "")

axis(side=1, at = c(-2,-1,-0.5,0,0.5,1,2), labels = FALSE)
text(x = c(-2,-1,-0.5,0,0.5,1,2), y = par("usr")[3]-0.1,
     labels = c("-2","-1","-1/2","0","1/2","1","2"),
     pos = 1, xpd = TRUE)

text(expression(tau),x = 0, y = -0.5, 
     pos = 1, xpd = TRUE, cex = 1.5)

abline(h = c(1.375,0.625))

plot.ci(c(-0.308,0.099),y.pos = 1.875, col = "black", 
        tick.size = 0.15, lwd = 2)
plot.ci(c(-0.357,0.219),y.pos = 1.625, col = "black", 
        tick.size = 0.15, lwd = 2, lty = 3)

plot.ci(c(-0.534,0.328),y.pos = 1.125, col = "black", 
        tick.size = 0.15, lwd = 2)
plot.ci(c(-0.574,0.464),y.pos = 0.875, col = "black", 
        tick.size = 0.15, lwd = 2, lty = 3)

plot.ci(c(-0.716,0.517),y.pos = 0.375, col = "black", 
        tick.size = 0.15, lwd = 2)
plot.ci(c(-0.771,0.666),y.pos = 0.125, col = "black", 
        tick.size = 0.15, lwd = 2, lty = 3)

text(expression(paste(Gamma," = ",1)),x = 1.5, y = 1.75, cex = 1, font = 2)
text(expression(paste(Gamma," = ",1.25)),x = 1.5, y = 1, cex = 1)
text(expression(paste(Gamma," = ",1.5)),x = 1.5, y = 0.25, cex = 1)

legend("top",legend = c("Constant", "Versions"),
       lwd = c(2,2), lty = c(1,3),inset = c(0,-0.2),
       bty = "n", horiz = TRUE, xpd = NA)
