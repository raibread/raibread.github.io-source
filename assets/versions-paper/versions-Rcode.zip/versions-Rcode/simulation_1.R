

set.seed(19)
# sample size settings
I <- 100
#n.b <- sample(c(2),I,replace = T)
#n.a <- 4-n.b
n.b <- rep(2,I)
n.a <- 4-n.b


# contstant effect
tau.c <- 0.4

power_comp <- function(tau,tau.a = 0,I,n_a,n_b,n_sim = 1000, alp = 0.05) {
  n <- n_a+n_b
  rej_sim <- matrix(rep(NA,n_sim*8),ncol = n_sim)
  for(i in 1:n_sim) {
    X <- rnorm(I)
    X.ct <- matrix(rep(X,n[1]),ncol = I, byrow = T)
    Y.tr  <- rnorm(I,mean = tau) + X
    Y.ct  <- matrix(rnorm((sum(n_a+n_b))),ncol = I) + X.ct
    
    
    for(j in 1:I) {
      Y.ct[1:n_a[j],j] <- Y.ct[1:n_a[j],j] + tau.a 
    }
    Y.all <- data.frame(Y = c(Y.tr,as.vector(Y.ct)),
                        X = c(X,as.vector(X.ct)),
                        Tr = c(rep("T",I),rep(NA,sum(n))),
                        group = c(1:I,rep(NA,sum(n))))
    
    levels(Y.all$Tr) <- c("Tr","C_a","C_b",NA)
    
    k <- I+1
    j <- 1
    while(k<(I+sum(n)) & j <= I) {
      m_a <- n_a[j]
      m_b <- n_b[j]
      Y.all[k:(k+m_a-1),"Tr"] <- "C_a"
      Y.all[(k+m_a):(k+m_a+m_b-1),"Tr"] <- "C_b"
      Y.all[k:(k+m_a+m_b-1),"group"] <- j
      j <- j+1
      k <- k+(m_a+m_b)
    }
    
    
    #Y.all <- rbind(Y.tr,Y.ct)
    
    x.0 <- mean(Y.tr - colMeans(Y.ct))
    s.0 <- sqrt(sum(1+1/(n_a+n_b))/I**2)
    
    x.a <- mean(Y.tr - sapply(1:I,function(k) mean(Y.ct[1:n_a[k],k])))
    s.a <- sqrt(sum(1+1/n_a)/I**2)
    
    x.b <- mean(Y.tr - sapply(1:I,function(k) mean(Y.ct[(n_a[k]+1):n[k],k])))
    s.b <- sqrt(sum(1+1/n_b)/I**2)
    
    x.ab <- mean(sapply(1:I,function(k) mean(Y.ct[1:n_a[k],k]))-sapply(1:I,function(k) mean(Y.ct[(n_a[k]+1):n[k],k])))
    s.ab <- sqrt(sum(1/n_b+1/n_a)/I**2)
    
    rej_sim[1,i] <- abs(x.0/s.0) > qnorm(1-alp/2) | abs(x.0/s.0) < qnorm(alp/2)
    rej_sim[2,i] <- (abs(x.0/s.0) > qnorm(1-alp/2) & 
      abs(x.b/s.b) > qnorm(1-alp/2) &
      abs(x.a/s.a) > qnorm(1-alp/2)) | 
      (abs(x.0/s.0) < qnorm(alp/2) & 
         abs(x.b/s.b) < qnorm(alp/2) &
         abs(x.a/s.a) < qnorm(alp/2)) 
    
    rej_sim[3,i] <- abs(x.a/s.a) > qnorm(1-alp/6) | abs(x.a/s.a) < qnorm(alp/6)
    rej_sim[4,i] <- abs(x.b/s.b) > qnorm(1-alp/6) | abs(x.b/s.b) < qnorm(alp/6)
    rej_sim[5,i] <- abs(x.0/s.0) > qnorm(1-alp/6) | abs(x.0/s.0) < qnorm(alp/6)
    rej_sim[6,i] <- abs(x.ab/s.ab) > qnorm(1-alp/6) | abs(x.ab/s.ab) < qnorm(alp/6)
    rej_sim[7,i] <- (abs(x.b/s.b) > qnorm(1-alp/6) | abs(x.b/s.b) < qnorm(alp/6)) & 
      (abs(x.a/s.a) > qnorm(1-alp/6) | abs(x.a/s.a) < qnorm(alp/6))
    xx <- anova(lm(Y~Tr+X,data = Y.all),lm(Y~X,data = Y.all))$`Pr(>F)`[2]
    #xx <- summary(lm(Y~Tr,data = Y.all))
    #rej_sim[8,i] <- pf(xx$fstatistic[1],xx$fstatistic[2],xx$fstatistic[3],lower.tail = F) < alp
    rej_sim[8,i] <- xx < alp
  }
  rownames(rej_sim) <- c("rej.c","rej.v","rej.a.bonf","rej.b.bonf","rej.c.bonf"
                         ,"rej.ab.bonf","rej.a_and_b.bonf","rej.F")
  return(rej_sim)
}

# constant effect
tau.a <- 0
rej.sim <- power_comp(tau.c,tau.a,I,n.a,n.b)
rowMeans(rej.sim)

# slightly modified effect
tau.a <- tau.c * 0.05
rej.sim <- power_comp(tau.c,tau.a,I,n.a,n.b)
rowMeans(rej.sim)

# slightly modified effect
tau.a <- tau.c * 0.1
rej.sim <- power_comp(tau.c,tau.a,I,n.a,n.b)
rowMeans(rej.sim)

# moderately modified effect
tau.a <- tau.c * 0.15
rej.sim <- power_comp(tau.c,tau.a,I,n.a,n.b)
rowMeans(rej.sim)

# moderately modified effect
tau.a <- tau.c * 0.2
rej.sim <- power_comp(tau.c,tau.a,I,n.a,n.b)
rowMeans(rej.sim)

# moderately modified effect
tau.a <- tau.c * 0.25
rej.sim <- power_comp(tau.c,tau.a,I,n.a,n.b)
rowMeans(rej.sim)

# moderately modified effect
tau.a <- tau.c * 0.3
rej.sim <- power_comp(tau.c,tau.a,I,n.a,n.b)
rowMeans(rej.sim)

# moderately modified effect
tau.a <- tau.c * 0.35
rej.sim <- power_comp(tau.c,tau.a,I,n.a,n.b)
rowMeans(rej.sim)

# moderately modified effect
tau.a <- tau.c * 0.4
rej.sim <- power_comp(tau.c,tau.a,I,n.a,n.b)
rowMeans(rej.sim)

# moderately modified effect
tau.a <- tau.c * 0.5
rej.sim <- power_comp(tau.c,tau.a,I,n.a,n.b)
rowMeans(rej.sim)

# severely modified effect
tau.a <- tau.c * 0.75
rej.sim <- power_comp(tau.c,tau.a,I,n.a,n.b)
rowMeans(rej.sim)

tau.a <- tau.c * (1.05)
rej.sim <- power_comp(tau.c,tau.a,I,n.a,n.b)
rowMeans(rej.sim)

tau.a <- tau.c * (2)
rej.sim <- power_comp(tau.c,tau.a,I,n.a,n.b)
rowMeans(rej.sim)
