## Versions tests and interals: This code includes
#  functions that performed the tests (version.tests) 
#  described in Sec.5.2 and construct the intervals
#  (version.intervals) described in Sec.5.3 of the paper.
#
#  The optmatch_process() S3 methods convert output from 
#  pairmatch() and fullmatch() from the optmatch package
#  to the format that senfm() and senfmCI() from the 
#  sensitivityfull package expect.

# load necessary library
library(sensitivityfull)

# method to do process optmatch output
optmatch_process <- function(x, match.result, data = NULL) UseMethod("optmatch_process", x)

# Default S3 method:
optmatch_process.default <- function(outcome, treated, match.result) {
  match.out <- as.data.frame(cbind(treated,as.numeric(match.result),outcome))
  names(match.out) <- c("Treated","Matched.Set","Outcome")
  return(shape.match(match.out))
}

# S3 method for class 'formula':
optmatch_process.formula <- function(formula, match.result, data) {
  match.ind <- as.numeric(match.result)
  y.Z       <- mapply(cbind,with(data,eval(attr(terms(formula),"variables"))))
  match.out <- as.data.frame(cbind(y.Z,match.ind)[,c(2,3,1)])
  names(match.out) <- c("Treated","Matched.Set","Outcome")
  return(shape.match(match.out))
}

# S3 method for class 'data.frame':
optmatch_process.data.frame <- function(data, outcome, treated, match.result) {
  match.out <- as.data.frame(cbind(data[,treated],as.numeric(match.result),data[,outcome]))
  names(match.out) <- c("Treated","Matched.Set","Outcome")
  return(shape.match(match.out))
}

# helper function to shape match to senfm format
shape.match <- function(match.result) {
  names(match.result) <- c("Treated","Matched.Set","Score")
  
  treated     <- with(match.result, aggregate(Treated ~ Matched.Set,
                                              FUN = function(x) as.numeric(sum(x) == 1)))
  
  names(treated)[2] <- "one.treated"
  
  match.result <- merge(match.result,treated, by = "Matched.Set")
  match.result <- with(match.result,
                       match.result[order(Matched.Set,abs(one.treated - Treated)),])
  
  tmp.Scores  <- with(match.result, aggregate(Score ~ Matched.Set, 
                                              FUN = function(x) x))
  
  
  n.col <- max(sapply(tmp.Scores[,2],length))

  y.out <- do.call(rbind,lapply(tmp.Scores[,2],
                                function(x) { length(x) <- n.col
                                              x }))
  
  rownames(y.out) <- tmp.Scores$Matched.Set
  
  return(list(treated = as.logical(treated$one.treated), 
              y = y.out))
}


# function to run a versioned test (optimal weights are used)
version.tests <- function(y, treated, y.versions = list(), 
                         treated.versions = list(), alpha = 0.05,...) {
  n.versions <- length(y.versions)
  
  p.1 <- min(senfm(y,treated,alternative = "greater",...)$pval,
             senfm(y,treated,alternative = "less",...)$pval)
  
  if(p.1 >= alpha/2 || n.versions == 0) {
    return(list(pvals = c(p.1,NA,NA), reject = c(0,0,0)))
  } else {
    p.min <- max(mapply(function(y,t) senfm(y,t,alternative = "greater",...)$pval,
                        y = y.versions,t = treated.versions))
    p.max <- max(mapply(function(y,t) senfm(y,t,alternative = "less",...)$pval,
                        y = y.versions,t = treated.versions))
    
    return(list(pvals = c(p.1,p.min,p.max), 
           reject = c(1,as.numeric(p.min < alpha/2),as.numeric(p.max < alpha/2))))
  }
}

# function to determine 1-\alpha level intervals \mathcal{I}_c and \mathcal{I}_v
version.intervals <- function(y,treated,y.versions = list(),treated.versions = list(), 
                              alpha = 0.05, gamma = 1, ...) {
  n.versions <- length(y.versions)
  
  CI.0 <- senfmCI(y,treated,alpha = alpha,gamma = gamma,...,
                  twosided = TRUE)$ConfidenceInterval
  if(n.versions > 0) {
    L.min <- min(mapply(function(y,t) senfmCI(y,t,alpha = alpha/2,...,twosided = FALSE,
                                            upper = TRUE,gamma = gamma)$ConfidenceInterval[1],
                         y = y.versions, t = treated.versions))
  
    U.max <- max(mapply(function(y,t) senfmCI(y,t,alpha = alpha/2,...,twosided = FALSE,
                                            upper = FALSE,gamma = gamma)$ConfidenceInterval[2],
                         y = y.versions, t = treated.versions))
  } else {
    L.min <- NA
    U.max <- NA
  }
  
  desc <- c(1-alpha,gamma,n.versions,"Constant (I_c) and Versions (I_v)")
  names(desc) <- c("Coverage","Gamma","Number of Versions","Confidence Intervals")
  
  return(list(I_c = CI.0, I_v = c(min(L.min,CI.0[1]),max(U.max,CI.0[2])),
              description = desc))
  
}