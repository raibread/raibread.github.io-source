## Football Analysis: This code constructs the version method 
#  confidence intervals (I_c and I_v) and the corresponding 
#  sensitivity intervals for Gamma = 1.25, 1.5, and 2 found in 
#  Sec.5.4 and Sec.6 of the paper.

# load match data
load("data.Rdata")

# load version test and interval functions
source("versions.R")

# All controls
tmp.1     <- shape.match(data.1)
y.1       <- tmp.1$y
treated.1 <- tmp.1$treated

# Non-sport controls
tmp.2     <- shape.match(data.2)
y.2       <- tmp.2$y
treated.2 <- tmp.2$treated

# Other-sport controls
tmp.3     <- shape.match(data.3)
y.3       <- tmp.3$y
treated.3 <- tmp.3$treated

# Collect versions
y.versions <- list(y.2,y.3)
t.versions <- list(treated.2,treated.3)

# Confidence Intervals (No hidden bias)
football.CIs        <- version.intervals(y.1,treated.1,y.versions,t.versions,
                                         trim = Inf)

# Sensitivity Intervals (Gamma = 1.25, 1.5, 2)
football.CIs.G_1.25 <- version.intervals(y.1,treated.1,y.versions,t.versions, 
                                         trim = Inf, gamma = 1.25)
football.CIs.G_1.5  <- version.intervals(y.1,treated.1,y.versions,t.versions, 
                                         trim = Inf, gamma = 1.5)
football.CIs.G_2    <- version.intervals(y.1,treated.1,y.versions,t.versions, 
                                         trim = Inf, gamma = 2)
