

plot.ci <- function(ci, y.pos, tick.size = 0.1, lty = 1,...) {
  segments(x0 = ci[1], x1 = ci[2],
           y0 = y.pos, y1 = y.pos, lty = lty,...)
  
  segments(x0 = ci[1], x1 = ci[1],
           y0 = y.pos - tick.size/2, 
           y1 = y.pos + tick.size/2, lty = 1,...)
  
  segments(x0 = ci[2], x1 = ci[2],
           y0 = y.pos - tick.size/2, 
           y1 = y.pos + tick.size/2, lty = 1,...)
}

plot(x=1,y=1, pch = NA, 
     xaxt = "n", xlab = "",
     xlim = c(-1,1), ylim = c(0,2),
     yaxt = "n", ylab = "")

axis(side=1, at = seq(-1,1,0.5), labels = FALSE)
text(x = c(-1,-0.5,0,0.5,1), y = par("usr")[3]-0.1,
     labels = c("-1","-1/2","0","1/2","1"),
     pos = 1, xpd = TRUE)

text(expression(tau),x = 0, y = -0.5, 
     pos = 1, xpd = TRUE, cex = 1.5)

abline(h = 1.25, col = "black", lty = 1)

plot.ci(c(-0.308,0.099),y.pos = 1.5, col = "gray", 
        tick.size = 0.15, lwd = 2)
plot.ci(c(-0.308,0.099),y.pos = 1.75, col = "black", 
        tick.size = 0.15, lwd = 2)

text("Constant",x = 0.75, y = 1.75, cex = 0.75, font = 2)
text("vs All Controls",x = 0.75, y = 1.5, cex = 0.75)

plot.ci(c(-0.357,0.219),y.pos = 0.875, col = "black", 
        tick.size = 0.15, lwd = 2, lty = 1)
plot.ci(c(-0.357,0.099),y.pos = 0.625, col = "gray", 
        tick.size = 0.15, lwd = 2, lty = 1)
plot.ci(c(-0.330,0.219),y.pos = 0.375, col = "gray", 
        tick.size = 0.15, lwd = 2, lty = 1)

text("Versions",x = 0.75, y = 0.875, cex = 0.75, font = 2)
text("vs No Sport",x = 0.75, y = 0.625, cex = 0.75)
text("vs Other Sport",x = 0.75, y = 0.375, cex = 0.75)

legend(x = -1, y = par("usr")[4]+0.5,legend = c("Versions Method", "Marginal"),
       col = c("black","gray"),lwd = c(2,2),
       bty = "n", horiz = TRUE, xpd = NA)
